#![windows_subsystem = "windows"]

use i18n_embed_fl as _;

pub mod auto_update;
pub mod error;
pub mod health;
#[cfg(target_os = "linux")]
pub mod managed_spotify;
pub mod proxy;
pub mod routes;
pub mod server;
pub mod update_job;
pub mod watcher;
#[cfg(windows)]
mod window_controls;

fn main() {
    spicetify::locale::localize();

    let config_root = spicetify::platform::default_spicetify_config_dir();
    let log_path = config_root.join("daemon.log");
    if let Err(e) = spicetify::logging::init_for_file(&log_path) {
        eprintln!("failed to initialize daemon logging: {e}");
    }

    std::panic::set_hook(Box::new(|info| {
        tracing::error!("panic: {info}");
    }));

    if let Err(err) = server::run() {
        tracing::error!("daemon fatal error: {err:#}");
        std::process::exit(1);
    }
}
