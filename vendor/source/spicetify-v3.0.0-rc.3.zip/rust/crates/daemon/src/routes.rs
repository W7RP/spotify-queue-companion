use std::sync::Arc;
use std::time::Duration;

use axum::Json;
use axum::Router;
use axum::extract::State;
use axum::extract::ws::{Message, WebSocket, WebSocketUpgrade};
use axum::http::{HeaderMap, HeaderValue, Method, StatusCode};
use axum::response::IntoResponse;
use axum::routing::{any, get, post};
use spicetify::commands::protocol;
use tokio_stream::StreamExt;
use tower_http::cors::{AllowHeaders, AllowOrigin, CorsLayer, ExposeHeaders};

use crate::server::DaemonState;
use crate::update_job::RendererEvent;
use crate::{health, proxy};

pub const ALLOWED_ORIGIN: &str = "https://xpui.app.spotify.com";

/// Header carrying the token apply injected into the patched client. CORS
/// only constrains browsers, so it is what actually keeps other local
/// software off the proxy.
pub use spicetify::daemon::token::HEADER as TOKEN_HEADER;

/// Subprotocol prefix a browser uses to present the token on a WebSocket.
/// `fetch` can set headers and `WebSocket` cannot, so the handshake's
/// `Sec-WebSocket-Protocol` offer is the only channel the client page has.
pub const TOKEN_PROTOCOL_PREFIX: &str = "spicetify.token.";

/// Marks an RPC reply as a failure. The success replies are
/// `spicetify:<module>:1`, so a caller cannot otherwise tell an error from a
/// command that answers with nothing.
pub const ERROR_PREFIX: &str = "error:";

/// Whether a request presents the daemon token. Missing token file means the
/// client was never patched by this install, so nothing is authorised.
pub fn authorized(state: &DaemonState, headers: &HeaderMap) -> bool {
    let expected = spicetify::daemon::token::read(&state.ctx.load().config_root);
    let Some(expected) = expected else { return false };
    headers
        .get(TOKEN_HEADER)
        .and_then(|v| v.to_str().ok())
        .is_some_and(|presented| spicetify::daemon::token::matches(&expected, presented))
}

/// The token offered as a `Sec-WebSocket-Protocol` value, with the protocol
/// string it was carried in. The protocol has to be echoed on the response or
/// the browser fails the handshake.
fn offered_token(headers: &HeaderMap) -> Option<(String, String)> {
    headers
        .get("sec-websocket-protocol")
        .and_then(|v| v.to_str().ok())?
        .split(',')
        .map(str::trim)
        .find_map(|proto| {
            proto
                .strip_prefix(TOKEN_PROTOCOL_PREFIX)
                .map(|tok| (proto.to_string(), tok.to_string()))
        })
}

/// The outcome of a WebSocket handshake's token check. Three states, because
/// how the token arrived decides the response: only the subprotocol route has
/// something the browser needs echoed back.
enum WsAuth {
    Rejected,
    /// Token presented in the `x-spicetify-token` header.
    ByHeader,
    /// Token presented in the `Sec-WebSocket-Protocol` offer, carrying the
    /// protocol string to echo.
    BySubprotocol(String),
}

/// Whether a WebSocket handshake is authorised, by header or by subprotocol.
fn ws_authorized(state: &DaemonState, headers: &HeaderMap) -> WsAuth {
    if authorized(state, headers) {
        return WsAuth::ByHeader;
    }
    let Some(expected) = spicetify::daemon::token::read(&state.ctx.load().config_root) else {
        return WsAuth::Rejected;
    };
    let Some((proto, presented)) = offered_token(headers) else {
        return WsAuth::Rejected;
    };
    if spicetify::daemon::token::matches(&expected, &presented) {
        WsAuth::BySubprotocol(proto)
    } else {
        WsAuth::Rejected
    }
}

fn cors_layer() -> CorsLayer {
    CorsLayer::new()
        .allow_origin(AllowOrigin::exact(HeaderValue::from_static(ALLOWED_ORIGIN)))
        .allow_methods([Method::GET, Method::POST, Method::PUT, Method::DELETE, Method::PATCH])
        .allow_headers(AllowHeaders::mirror_request())
        .expose_headers(ExposeHeaders::any())
        .allow_private_network(true)
        .max_age(Duration::from_hours(24))
}

pub fn build(state: Arc<DaemonState>) -> Router {
    Router::new()
        .route("/health", get(health::handler))
        .route("/rpc", get(ws_handler))
        .route("/window-controls", get(window_controls_handler))
        .route("/shutdown", post(shutdown_handler))
        .route("/jobs/update-and-apply", get(update_job_status).post(update_job_admit))
        .route("/jobs/update-and-apply/event", post(update_job_event))
        .route("/spotify", get(managed_spotify_status))
        .route("/spotify/check", post(managed_spotify_check))
        .route("/spotify/update", post(managed_spotify_update))
        .route("/proxy", get(proxy::status))
        .route("/proxy/", get(proxy::status))
        .route("/proxy/{*url}", any(proxy::handler))
        .layer(cors_layer())
        .with_state(state)
}

async fn managed_spotify_status(
    State(state): State<Arc<DaemonState>>,
    headers: HeaderMap,
) -> axum::response::Response {
    if !authorized(&state, &headers) {
        return (StatusCode::FORBIDDEN, "invalid daemon token").into_response();
    }
    #[cfg(target_os = "linux")]
    return match tokio::task::spawn_blocking(move || state.managed_spotify.snapshot()).await {
        Ok(Ok(snapshot)) => Json(snapshot).into_response(),
        Ok(Err(error)) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("cannot read managed Spotify status: {error:#}"),
        )
            .into_response(),
        Err(error) => (StatusCode::INTERNAL_SERVER_ERROR, error.to_string()).into_response(),
    };
    #[cfg(not(target_os = "linux"))]
    Json(serde_json::json!({"installation":{"kind":"external"},"job":{"kind":"idle"}}))
        .into_response()
}

async fn managed_spotify_check(
    State(state): State<Arc<DaemonState>>,
    headers: HeaderMap,
) -> axum::response::Response {
    if !authorized(&state, &headers) {
        return (StatusCode::FORBIDDEN, "invalid daemon token").into_response();
    }
    #[cfg(target_os = "linux")]
    return match tokio::task::spawn_blocking(move || {
        let ctx = state.ctx.load_full();
        let _guard = spicetify::commands::guard::try_acquire(&ctx.config_root)?;
        spicetify::commands::spotify::check_update(&ctx)
    })
    .await
    {
        Ok(Ok(available)) => Json(available).into_response(),
        Ok(Err(error)) => {
            (StatusCode::CONFLICT, format!("cannot check Spotify packages: {error:#}"))
                .into_response()
        }
        Err(error) => (StatusCode::INTERNAL_SERVER_ERROR, error.to_string()).into_response(),
    };
    #[cfg(not(target_os = "linux"))]
    (StatusCode::NOT_IMPLEMENTED, "managed Spotify packages require Linux").into_response()
}

async fn managed_spotify_update(
    State(state): State<Arc<DaemonState>>,
    headers: HeaderMap,
) -> axum::response::Response {
    if !authorized(&state, &headers) {
        return (StatusCode::FORBIDDEN, "invalid daemon token").into_response();
    }
    #[cfg(target_os = "linux")]
    return match tokio::task::spawn_blocking(move || state.managed_spotify.admit()).await {
        Ok(Ok(admission)) => (StatusCode::ACCEPTED, Json(admission)).into_response(),
        Ok(Err(error)) => (StatusCode::CONFLICT, format!("cannot start Spotify update: {error:#}"))
            .into_response(),
        Err(error) => (StatusCode::INTERNAL_SERVER_ERROR, error.to_string()).into_response(),
    };
    #[cfg(not(target_os = "linux"))]
    (StatusCode::NOT_IMPLEMENTED, "managed Spotify packages require Linux").into_response()
}

async fn update_job_status(
    State(state): State<Arc<DaemonState>>,
    headers: HeaderMap,
) -> impl IntoResponse {
    if !authorized(&state, &headers) {
        return (StatusCode::FORBIDDEN, "invalid daemon token").into_response();
    }
    state.update_job.mark_client_seen();
    (StatusCode::OK, Json(state.update_job.status())).into_response()
}

async fn update_job_admit(
    State(state): State<Arc<DaemonState>>,
    headers: HeaderMap,
) -> impl IntoResponse {
    if !authorized(&state, &headers) {
        return (StatusCode::FORBIDDEN, "invalid daemon token").into_response();
    }
    match state.update_job.admit().await {
        Ok(admission) => (StatusCode::ACCEPTED, Json(admission)).into_response(),
        Err(message) => (StatusCode::CONFLICT, message).into_response(),
    }
}

async fn update_job_event(
    State(state): State<Arc<DaemonState>>,
    headers: HeaderMap,
    Json(event): Json<RendererEvent>,
) -> impl IntoResponse {
    if !authorized(&state, &headers) {
        return (StatusCode::FORBIDDEN, "invalid daemon token").into_response();
    }
    match state.update_job.renderer_event(event).await {
        Ok(ack) => (StatusCode::OK, Json(ack)).into_response(),
        Err(message) => (StatusCode::CONFLICT, message).into_response(),
    }
}

async fn ws_handler(
    ws: WebSocketUpgrade,
    State(state): State<Arc<DaemonState>>,
    headers: HeaderMap,
) -> impl IntoResponse {
    let origin = headers.get("origin").and_then(|v| v.to_str().ok()).unwrap_or("");

    if !origin.is_empty() && origin != ALLOWED_ORIGIN {
        tracing::warn!(%origin, "WebSocket connection rejected: origin not allowed");
        return (StatusCode::FORBIDDEN, "origin not allowed").into_response();
    }

    let ws = match ws_authorized(&state, &headers) {
        WsAuth::Rejected => {
            tracing::warn!("WebSocket connection rejected: missing or invalid daemon token");
            return (StatusCode::FORBIDDEN, "invalid daemon token").into_response();
        }
        WsAuth::ByHeader => ws,
        WsAuth::BySubprotocol(proto) => ws.protocols([proto]),
    };
    ws.on_upgrade(move |socket| handle_ws(socket, state))
}

async fn window_controls_handler(
    ws: WebSocketUpgrade,
    State(state): State<Arc<DaemonState>>,
    headers: HeaderMap,
) -> impl IntoResponse {
    if headers.get("origin").and_then(|value| value.to_str().ok()) != Some(ALLOWED_ORIGIN) {
        return (StatusCode::FORBIDDEN, "origin not allowed").into_response();
    }
    let ws = match ws_authorized(&state, &headers) {
        WsAuth::Rejected => return (StatusCode::FORBIDDEN, "invalid daemon token").into_response(),
        WsAuth::ByHeader => ws,
        WsAuth::BySubprotocol(protocol) => ws.protocols([protocol]),
    };
    #[cfg(windows)]
    return ws
        .on_upgrade(move |socket| crate::window_controls::serve(socket, state))
        .into_response();
    #[cfg(not(windows))]
    {
        let _ = ws;
        (StatusCode::NOT_IMPLEMENTED, "native window controls require Windows").into_response()
    }
}

async fn handle_ws(mut socket: WebSocket, state: Arc<DaemonState>) {
    while let Some(Ok(msg)) = socket.next().await {
        if let Message::Text(text) = msg {
            tracing::info!("{}", spicetify::fl!("rpc-received", msg = text.as_str()));
            let settings = text.starts_with("spicetify:settings:");
            match dispatch_rpc(state.ctx.load_full(), text.to_string()).await {
                Ok(res) if !res.is_empty() => {
                    if settings {
                        reload_config(&state);
                    }
                    if let Err(e) = socket.send(Message::Text(res.into())).await {
                        tracing::warn!(error = %e, "failed to send ws message");
                    }
                }
                // A caller that acts on the reply cannot distinguish failure
                // from a command whose reply is empty by design, so failures
                // are reported rather than only logged.
                Err(e) => {
                    tracing::warn!("{}", spicetify::fl!("protocol-error", err = e.to_string()));
                    let reply = format!("{ERROR_PREFIX}{e}");
                    if let Err(e) = socket.send(Message::Text(reply.into())).await {
                        tracing::warn!(error = %e, "failed to send ws message");
                    }
                }
                _ => {}
            }
        }
    }
}

/// Reloads config.toml now rather than on the watcher's debounce, so a
/// settings change is in effect by the time its caller hears back.
fn reload_config(state: &DaemonState) {
    let base = state.ctx.load_full();
    match spicetify::context::Config::load(&base.config_file)
        .and_then(|cfg| spicetify::context::AppContext::from_config(base.config_root.clone(), &cfg))
    {
        Ok(ctx) => state.ctx.store(ctx),
        Err(e) => tracing::warn!(error = %e, "could not reload config.toml"),
    }
}

async fn dispatch_rpc(
    ctx: Arc<spicetify::context::AppContext>,
    text: String,
) -> anyhow::Result<String> {
    tokio::task::spawn_blocking(move || {
        protocol::handle(&ctx, &text, spicetify::commands::apply::ApplyMode::Daemon)
    })
    .await?
}

// A cross-origin POST is sent even when the browser refuses to let the page
// read the reply, so without a token any page the user visits could stop the
// daemon and silently disable auto re-apply.
async fn shutdown_handler(
    State(state): State<Arc<DaemonState>>,
    headers: HeaderMap,
) -> impl IntoResponse {
    if !authorized(&state, &headers) {
        tracing::warn!("shutdown request rejected: missing or invalid daemon token");
        return (StatusCode::FORBIDDEN, "invalid daemon token".to_string()).into_response();
    }
    #[cfg(target_os = "linux")]
    if state.managed_spotify.running() {
        return (StatusCode::CONFLICT, "a managed Spotify update is in progress".to_string())
            .into_response();
    }
    tracing::info!("{}", spicetify::fl!("shutdown-requested"));
    state.shutdown.notify_waiters();
    (StatusCode::ACCEPTED, spicetify::fl!("daemon-stopping-resp")).into_response()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn apply_rpc_does_not_block_the_server_while_waiting_for_the_apply_lock()
    -> anyhow::Result<()> {
        use spicetify::context::{AppContext, Config};
        use std::fs::OpenOptions;

        let nonce = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)?.as_nanos();
        let root =
            std::env::temp_dir().join(format!("spicetify-rpc-{}-{nonce}", std::process::id()));
        // Foreign apply artifacts make the command fail before it can touch Spotify.
        std::fs::create_dir_all(root.join("Apps/xpui"))?;
        let ctx = Arc::new(AppContext::from_config(
            root.clone(),
            &Config {
                spotify_exec: Some(root.join("Spotify")),
                spotify_data_dir: Some(root.clone()),
                offline_bnk_dir: Some(root.clone()),
                ..Config::default()
            },
        )?);
        let lock = OpenOptions::new()
            .create(true)
            .truncate(false)
            .write(true)
            .open(root.join("spicetify-apply.lock"))?;
        lock.lock()?;
        let (release, held) = std::sync::mpsc::channel();
        // A bounded external release keeps a regression from hanging the test runtime.
        let holder = std::thread::spawn(move || {
            let _ = held.recv_timeout(Duration::from_secs(5));
            drop(lock);
        });
        let rpc = tokio::spawn(dispatch_rpc(ctx, "spicetify:0:apply".to_string()));
        let started = std::time::Instant::now();
        tokio::time::sleep(Duration::from_millis(50)).await;
        let responsive = started.elapsed() < Duration::from_secs(2) && !rpc.is_finished();
        let _ = release.send(());
        let result = rpc.await?;
        holder.join().expect("lock holder exits");
        std::fs::remove_dir_all(root)?;
        assert!(result.is_err(), "fixture must refuse a foreign apply");
        assert!(responsive, "the server must keep polling while Apply waits on disk");
        Ok(())
    }

    fn headers(protocols: &str) -> HeaderMap {
        let mut h = HeaderMap::new();
        let _ =
            h.insert("sec-websocket-protocol", HeaderValue::from_str(protocols).expect("header"));
        h
    }

    #[test]
    fn reads_the_token_from_a_subprotocol_offer() {
        let (proto, token) =
            offered_token(&headers("spicetify.token.abc123")).expect("token is offered");
        assert_eq!(token, "abc123");
        assert_eq!(proto, "spicetify.token.abc123", "the offer has to be echoed verbatim");
    }

    #[test]
    fn picks_the_token_out_of_a_multi_protocol_offer() {
        let (_, token) =
            offered_token(&headers("chat, spicetify.token.abc123, superchat")).expect("token");
        assert_eq!(token, "abc123");
    }

    #[test]
    fn ignores_an_offer_carrying_no_token() {
        assert!(offered_token(&headers("chat, superchat")).is_none());
        assert!(offered_token(&HeaderMap::new()).is_none());
    }
}
