pub mod release;

use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;

use anyhow::Context;
pub use release::{ChecksumError, ReleaseInfo};
use semver::Version;
use tokio::io::AsyncWriteExt;
use tokio_stream::StreamExt;

use crate::error::Result;

// The release list, not `/releases/latest`: v3 ships as prereleases, which
// that endpoint never returns (it serves the newest stable, still a v2 tag),
// so self-update on a beta compared itself against v2 and always answered
// "already up to date". install.sh lists releases for the same reason.
const GITHUB_API: &str = "https://api.github.com/repos/spicetify/cli/releases?per_page=30";

pub async fn check_for_update(arch: &'static str) -> Result<Option<ReleaseInfo>> {
    let client = crate::http::github_client()?;
    let response = client
        .get(GITHUB_API)
        .send()
        .await
        .and_then(reqwest::Response::error_for_status)
        .context("failed to fetch the release list")?;

    let releases: Vec<ReleaseInfo> =
        response.json().await.context("failed to parse release JSON")?;
    let current = Version::parse(crate::VERSION).context("invalid current version")?;
    Ok(newest_release(releases, &current, arch != std::env::consts::ARCH, arch))
}

/// The newest release by semver precedence when it is newer than `current`.
/// Prereleases are candidates on purpose (they are the only v3 releases);
/// semver already ranks `3.0.0` above `3.0.0-beta.*`, so once a stable v3
/// exists it wins naturally, and the v2 era's tags lose on major.
/// Unparsable tags are skipped.
fn newest_release(
    releases: Vec<ReleaseInfo>,
    current: &Version,
    migrate_arch: bool,
    arch: &str,
) -> Option<ReleaseInfo> {
    releases
        .into_iter()
        .filter_map(|release| Version::parse(&release.version()).ok().map(|v| (v, release)))
        .max_by(|(a, _), (b, _)| a.cmp(b))
        .filter(|(version, release)| {
            version > current
                || (migrate_arch
                    && version == current
                    && release.find_platform_asset(arch).is_some())
        })
        .map(|(_, release)| release)
}

#[derive(Debug)]
pub struct StagedUpdate {
    pub version: String,
    arch: &'static str,
    new_binary: PathBuf,
    daemon_binary: Option<PathBuf>,
    staging_dir: PathBuf,
}

pub async fn download_update(
    release: &ReleaseInfo,
    arch: &'static str,
    on_progress: impl Fn(u64, u64) + Send + 'static,
) -> Result<StagedUpdate> {
    let asset = release.find_platform_asset(arch).ok_or_else(|| {
        let names = release::candidate_asset_names(&release.version(), arch);
        anyhow::anyhow!("no release asset found for platform; tried: {}", names.join(", "))
    })?;

    let version = release.version();
    let install_dir = install_dir()?;
    let staging_dir = install_dir.join(".updates").join(&version);

    if staging_dir.exists() {
        std::fs::remove_dir_all(&staging_dir).context("failed to clean staging dir")?;
    }
    std::fs::create_dir_all(&staging_dir).context("failed to create staging dir")?;

    let archive_path = staging_dir.join(&asset.name);
    download_with_progress(&asset.browser_download_url, &archive_path, &on_progress).await?;

    if let Some(checksum_asset) = release.find_checksum_asset(&asset.name) {
        fetch_and_verify_checksum(checksum_asset, &archive_path).await?;
    } else {
        let computed = release::compute_sha256(&archive_path).unwrap_or_default();
        anyhow::bail!(
            "no checksum asset found in release for {}; computed sha256: {computed}",
            asset.name,
        );
    }

    extract_archive(&archive_path, &staging_dir)?;

    let new_binary = staging_dir.join(release::binary_name());
    verify_staged_binary(&new_binary)?;

    let daemon_binary = {
        let daemon_name = crate::daemon::daemon_binary_name();
        let p = staging_dir.join(daemon_name);
        if p.exists() { Some(p) } else { None }
    };

    Ok(StagedUpdate { version, arch, new_binary, daemon_binary, staging_dir })
}

pub fn install_update(staged: &StagedUpdate) -> Result<()> {
    let current_exe = std::env::current_exe()?;
    let install_dir = current_exe.parent().context("exe has no parent dir")?;
    let daemon = staged.daemon_binary.as_ref().and_then(|staged| {
        let path = install_dir.join(crate::daemon::daemon_binary_name());
        path.exists().then_some((staged, path))
    });

    // A supervisor restarts a stopped daemon at once, racing the replacement,
    // and Unix lets a running binary be renamed away. So a supervised daemon
    // keeps running while both binaries are replaced, then its supervisor
    // restarts it onto the new one.
    let supervised =
        cfg!(unix) && daemon.is_some() && crate::daemon::DaemonManager::create().is_installed();
    if supervised {
        if let Some((staged_daemon, path)) = &daemon {
            replace_binary(staged_daemon, path).context("failed to replace daemon binary")?;
        }
        replace_binary(&staged.new_binary, &current_exe)
            .context("failed to replace main binary")?;
        match crate::daemon::DaemonManager::create().restart_supervised() {
            Ok(true) => tracing::info!("restarted the daemon onto the new version"),
            Ok(false) => {
                tracing::warn!("no supervisor restarted the daemon; run `spicetify daemon start`");
            }
            Err(e) => {
                tracing::warn!(error = %e, "could not restart the daemon; run `spicetify daemon start`");
            }
        }
    } else {
        // Older x64 updaters stop the daemon before launching this migration.
        let restart_daemon = staged.daemon_binary.is_some()
            && (crate::daemon::is_daemon_running()
                || (staged.arch != std::env::consts::ARCH
                    && crate::daemon::DaemonManager::create().is_installed()));
        let replaced = (|| -> Result<()> {
            if let Some((staged_daemon, path)) = &daemon {
                crate::daemon::shutdown_daemon();
                let deadline = std::time::Instant::now() + Duration::from_secs(5);
                while crate::daemon::is_daemon_running() {
                    if std::time::Instant::now() > deadline {
                        tracing::warn!(
                            "daemon did not shut down within 5s; replacing binary anyway"
                        );
                        break;
                    }
                    std::thread::sleep(Duration::from_millis(50));
                }
                replace_binary(staged_daemon, path).context("failed to replace daemon binary")?;
            }
            replace_binary(&staged.new_binary, &current_exe)
                .context("failed to replace main binary")
        })();
        // A failed replacement leaves the previous binaries in place, so the
        // daemon this stopped still has something to restart onto.
        if restart_daemon && let Err(e) = crate::daemon::process::spawn() {
            if replaced.is_ok() {
                return Err(anyhow::Error::new(e).context("failed to restart updated daemon"));
            }
            tracing::warn!(error = %e, "failed to restart the daemon after a failed update");
        }
        replaced?;
    }

    if let Err(e) = std::fs::remove_dir_all(&staged.staging_dir) {
        tracing::warn!(error = %e, "failed to remove staging dir");
    }

    tracing::info!(version = %staged.version, "spawning updated binary");
    let args: Vec<String> = std::env::args().skip(1).collect();
    let child = std::process::Command::new(&current_exe)
        .args(&args)
        .spawn()
        .context("failed to spawn updated binary")?;

    tracing::info!(pid = child.id(), "spawned updated process, exiting");
    std::process::exit(0);
}

/// The folder the official installer puts the binaries in: `~/.spicetify`,
/// or `%LOCALAPPDATA%\spicetify` on Windows.
#[must_use]
pub fn official_install_dir() -> Option<PathBuf> {
    let dirs = directories::BaseDirs::new()?;
    #[cfg(windows)]
    let dir = dirs.data_local_dir().join("spicetify");
    #[cfg(not(windows))]
    let dir = dirs.home_dir().join(".spicetify");
    Some(dir)
}

/// Whether the running binary lives in `dir`.
#[must_use]
pub fn is_official_install(dir: &Path) -> bool {
    let exe_dir = std::env::current_exe()
        .and_then(std::fs::canonicalize)
        .ok()
        .and_then(|exe| exe.parent().map(Path::to_path_buf));
    exe_dir.is_some_and(|exe_dir| std::fs::canonicalize(dir).is_ok_and(|dir| dir == exe_dir))
}

pub fn startup_cleanup() {
    let Ok(install_dir) = install_dir() else { return };

    cleanup_old_files(&install_dir);
    cleanup_staging_dirs(&install_dir);
}

fn install_dir() -> Result<PathBuf> {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(Path::to_path_buf))
        .context("cannot determine install directory")
}

fn replace_binary(new: &Path, target: &Path) -> Result<()> {
    let backup = target.with_extension("old");

    if let Err(e) = std::fs::remove_file(&backup)
        && e.kind() != std::io::ErrorKind::NotFound
    {
        tracing::warn!(error = %e, "failed to remove old backup");
    }

    std::fs::rename(target, &backup).with_context(|| {
        format!(
            "failed to rename {} to {}; close other processes holding a lock",
            target.display(),
            backup.display()
        )
    })?;

    if let Err(e) = std::fs::rename(new, target) {
        if let Err(rollback) = std::fs::rename(&backup, target) {
            tracing::error!(
                error = %e,
                rollback_error = %rollback,
                "binary replace failed; rollback also failed; attempting copy as fallback"
            );
        } else {
            tracing::warn!(error = %e, "binary rename failed, rolled back; attempting copy");
        }

        let copied = std::fs::copy(new, target).with_context(|| {
            format!(
                "failed to copy {} to {} after rename failed ({e}); target {}",
                new.display(),
                target.display(),
                if target.exists() { "restored from backup" } else { "lost" },
            )
        })?;
        if copied == 0 {
            anyhow::bail!(
                "copy of {} to {} wrote 0 bytes; target {}",
                new.display(),
                target.display(),
                if target.exists() { "restored from backup" } else { "lost" },
            );
        }

        tracing::warn!("rename failed ({e}), used copy instead");
        if let Err(e) = std::fs::remove_file(new) {
            tracing::warn!(error = %e, "failed to remove staged binary after copy");
        }
    }

    if let Err(e) = std::fs::remove_file(&backup) {
        tracing::warn!(error = %e, "failed to remove backup binary");
    }

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(target, std::fs::Permissions::from_mode(0o755))?;
    }

    Ok(())
}

fn cleanup_old_files(install_dir: &Path) {
    let Ok(entries) = std::fs::read_dir(install_dir) else { return };
    for entry in entries.filter_map(std::result::Result::ok) {
        let path = entry.path();
        if path.extension().is_some_and(|e| e == "old")
            && path.is_file()
            && let Err(e) = std::fs::remove_file(&path)
        {
            tracing::warn!(error = %e, path = %path.display(), "failed to clean up old binary");
        }
    }
}

fn cleanup_staging_dirs(install_dir: &Path) {
    let updates_dir = install_dir.join(".updates");
    if updates_dir.exists()
        && let Err(e) = std::fs::remove_dir_all(&updates_dir)
        && e.kind() != std::io::ErrorKind::NotFound
    {
        tracing::warn!(error = %e, "failed to clean up updates staging dir");
    }
}

async fn download_with_progress(
    url: &str,
    dest: &Path,
    on_progress: &(impl Fn(u64, u64) + Send + 'static),
) -> Result<()> {
    let client = crate::http::download_client()?;

    let response = client
        .get(url)
        .send()
        .await
        .and_then(reqwest::Response::error_for_status)
        .context("download request failed")?;

    let total = response.content_length().unwrap_or(0);
    let downloaded = AtomicU64::new(0);

    if let Some(parent) = dest.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }

    let mut file = tokio::fs::File::create(dest).await?;
    let mut stream = response.bytes_stream();

    while let Some(chunk) = stream.next().await {
        let chunk = chunk.context("stream error during download")?;
        file.write_all(&chunk).await?;
        let n = downloaded.fetch_add(chunk.len() as u64, Ordering::Relaxed) + chunk.len() as u64;
        if total > 0 {
            on_progress(n, total);
        }
    }

    file.flush().await?;
    Ok(())
}

fn extract_archive(archive_path: &Path, dest: &Path) -> Result<()> {
    let is_zip = archive_path.extension().is_some_and(|ext| ext.eq_ignore_ascii_case("zip"));
    let is_tar_zst =
        archive_path.to_str().is_some_and(|n| n.to_ascii_lowercase().ends_with(".tar.zst"));

    if is_zip {
        crate::util::unzip_file(archive_path, dest).context("failed to unzip archive")?;
    } else if is_tar_zst {
        let bytes = std::fs::read(archive_path).context("failed to read archive")?;
        crate::util::untar_zst_bytes(&bytes, dest).context("failed to extract tar.zst")?;
    } else {
        let name = archive_path.file_name().and_then(|n| n.to_str()).unwrap_or("unknown");
        anyhow::bail!("unsupported archive format: {name}");
    }

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let binary = dest.join(release::binary_name());
        if binary.exists()
            && let Err(e) =
                std::fs::set_permissions(&binary, std::fs::Permissions::from_mode(0o755))
        {
            tracing::warn!(error = %e, "failed to set executable permission on extracted binary");
        }
    }

    Ok(())
}

fn verify_staged_binary(path: &Path) -> Result<()> {
    let output = std::process::Command::new(path)
        .arg("--version")
        .output()
        .context("failed to run staged binary --version")?;

    if output.status.success() {
        return Ok(());
    }

    let stderr = String::from_utf8_lossy(&output.stderr);
    anyhow::bail!("staged binary --version check failed: {stderr}");
}

async fn fetch_and_verify_checksum(
    checksum_asset: &release::ReleaseAsset,
    archive_path: &Path,
) -> Result<()> {
    let client = crate::http::client(30)?;

    let response = client
        .get(&checksum_asset.browser_download_url)
        .send()
        .await
        .and_then(reqwest::Response::error_for_status)
        .context("failed to download checksum file")?;

    let body = response.text().await.context("failed to read checksum body")?;
    let expected = body.split_whitespace().next().unwrap_or("").trim();

    if expected.is_empty() {
        anyhow::bail!("checksum file is empty");
    }

    release::verify_checksum(archive_path, expected).context("checksum verification failed")?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn only_the_folder_holding_this_binary_counts_as_the_install() {
        let exe = std::env::current_exe().expect("test binary");
        let dir = exe.parent().expect("parent");
        assert!(is_official_install(dir));
        assert!(!is_official_install(&std::env::temp_dir()));
        assert!(!is_official_install(&dir.join("missing")), "a folder that doesn't exist");
    }

    fn release(tag: &str) -> ReleaseInfo {
        ReleaseInfo {
            tag_name: tag.to_string(),
            name: String::new(),
            body: String::new(),
            assets: Vec::new(),
        }
    }

    #[test]
    fn emulated_cli_can_migrate_at_the_current_version() {
        let current = Version::parse("3.0.0-beta.20").unwrap();
        let mut published = release("v3.0.0-beta.20");
        published.assets.push(release::ReleaseAsset {
            name: release::candidate_asset_names(&published.version(), std::env::consts::ARCH)[0]
                .clone(),
            browser_download_url: "https://example.com/native.zip".into(),
            size: 1,
        });
        assert!(
            newest_release(vec![published.clone()], &current, true, std::env::consts::ARCH)
                .is_some()
        );
        assert!(newest_release(vec![published], &current, false, std::env::consts::ARCH).is_none());
        assert!(
            newest_release(vec![release("v3.0.0-beta.20")], &current, true, std::env::consts::ARCH)
                .is_none()
        );
        assert!(
            newest_release(vec![release("v3.0.0-beta.19")], &current, true, std::env::consts::ARCH)
                .is_none()
        );
    }

    #[test]
    fn offers_the_newest_prerelease_over_a_stable_v2() {
        // The /releases/latest endpoint served v2.44.0 to v3 betas, which
        // made every self-update a no-op; the list-based picker must rank
        // the v3 prereleases above the v2 stables.
        let current = Version::parse("3.0.0-beta.5").expect("current");
        let picked = newest_release(
            vec![release("v3.0.0-beta.7"), release("v2.44.0"), release("v3.0.0-beta.6")],
            &current,
            false,
            std::env::consts::ARCH,
        )
        .expect("an update is offered");
        assert_eq!(picked.tag_name, "v3.0.0-beta.7");
    }

    #[test]
    fn stays_put_when_nothing_newer_exists() {
        let current = Version::parse("3.0.0-beta.7").expect("current");
        assert!(
            newest_release(
                vec![release("v3.0.0-beta.7"), release("v2.44.0")],
                &current,
                false,
                std::env::consts::ARCH
            )
            .is_none()
        );
        assert!(
            newest_release(vec![release("not-a-version")], &current, false, std::env::consts::ARCH)
                .is_none()
        );
    }

    #[test]
    fn a_stable_v3_wins_over_its_own_prereleases() {
        let current = Version::parse("3.0.0-beta.7").expect("current");
        let picked = newest_release(
            vec![release("v3.0.0"), release("v3.0.0-beta.9")],
            &current,
            false,
            std::env::consts::ARCH,
        )
        .expect("stable outranks beta");
        assert_eq!(picked.tag_name, "v3.0.0");
    }
}
