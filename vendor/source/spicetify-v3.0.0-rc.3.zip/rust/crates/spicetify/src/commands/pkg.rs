// `pkg`: install modules by identifier, resolved through the vault catalog.
//
// One registry: modules reach users by being submitted to it, where every
// entry is reviewed, checksummed and revocable. Code from anywhere else is
// still installable, but only by naming its artifact explicitly, which is a
// deliberate act rather than a source the CLI consults on its own.

use std::collections::BTreeMap;
use std::path::Path;

use serde::Deserialize;

use crate::context::AppContext;
use crate::error::Result;

const DEFAULT_VAULT: &str = "https://raw.githubusercontent.com/spicetify/modules/main/vault.json";

#[derive(Debug, Deserialize)]
struct VaultVersion {
    #[serde(default)]
    artifacts: Vec<String>,
    // Written by the publish pipeline; install refuses bytes that do not
    // match it.
    #[serde(default)]
    checksum: String,
}

#[derive(Debug, Deserialize)]
struct VaultModule {
    #[serde(default)]
    enabled: String,
    #[serde(default)]
    v: BTreeMap<String, VaultVersion>,
}

#[derive(Debug, Deserialize)]
struct Vault {
    #[serde(default)]
    modules: BTreeMap<String, VaultModule>,
}

fn fetch_vault_body(url: &str) -> Result<String> {
    crate::http::vault_client()
        .get(url)
        .send()
        .map_err(|e| anyhow::anyhow!("cannot fetch vault {url}: {e}"))?
        .text()
        .map_err(|e| anyhow::anyhow!("cannot read vault {url}: {e}"))
}

const VAULT_CACHE_TTL: std::time::Duration = std::time::Duration::from_mins(5);

fn vault_cache_path(config_root: &Path) -> std::path::PathBuf {
    config_root.join("cache").join("vault.json")
}

/// The registry, served through a short-lived disk cache. A fresh cached
/// copy skips the network entirely: `apply` is a recovery path and must not
/// stall behind a hung fetch, and one store-driven update otherwise touches
/// the vault up to three times (catalog, checksum, refresh). A failed fetch
/// falls back to whatever is cached, however stale, with a warning, so an
/// offline apply still evaluates the system modules instead of skipping.
fn cached_vault(config_root: &Path) -> Result<Vault> {
    vault_via_cache(
        &vault_cache_path(config_root),
        VAULT_CACHE_TTL,
        std::time::SystemTime::now(),
        || fetch_vault_body(DEFAULT_VAULT),
    )
}

fn read_cached_vault(path: &Path) -> Option<Vault> {
    serde_json::from_str(&std::fs::read_to_string(path).ok()?).ok()
}

fn vault_via_cache(
    path: &Path,
    ttl: std::time::Duration,
    now: std::time::SystemTime,
    fetch: impl FnOnce() -> Result<String>,
) -> Result<Vault> {
    let fresh = std::fs::metadata(path)
        .and_then(|meta| meta.modified())
        .ok()
        .and_then(|modified| now.duration_since(modified).ok())
        .is_some_and(|age| age <= ttl);
    // A corrupt cache never satisfies a read, fresh or stale, so it simply
    // falls through to the fetch.
    if fresh && let Some(vault) = read_cached_vault(path) {
        return Ok(vault);
    }
    match fetch() {
        Ok(body) => {
            let vault = serde_json::from_str(&body)
                .map_err(|e| anyhow::anyhow!("malformed vault {DEFAULT_VAULT}: {e}"))?;
            if let Some(dir) = path.parent() {
                let _ = std::fs::create_dir_all(dir);
            }
            if let Err(e) = std::fs::write(path, &body) {
                tracing::warn!("cannot cache the vault at {}: {e}", path.display());
            }
            Ok(vault)
        }
        Err(e) => match read_cached_vault(path) {
            Some(vault) => {
                tracing::warn!("vault fetch failed ({e}); using the cached copy");
                Ok(vault)
            }
            None => Err(e),
        },
    }
}

/// The pinned `enabled` version when the vault names one, otherwise the
/// highest version by semver precedence. The map's own key order is
/// lexicographic, which puts 1.7.0 above 1.10.0; a key that does not parse
/// as semver ranks below every one that does.
fn resolve_version(module: &VaultModule) -> Result<String> {
    if !module.enabled.is_empty() {
        if module.v.contains_key(&module.enabled) {
            return Ok(module.enabled.clone());
        }
        anyhow::bail!("enabled version {} is not in the vault", module.enabled);
    }
    module
        .v
        .keys()
        .max_by_key(|k| semver::Version::parse(k).ok())
        .cloned()
        .ok_or_else(|| anyhow::anyhow!("no versions in the vault"))
}

/// Installed modules, read from disk rather than the vault.
fn installed(config_root: &Path) -> Vec<(String, String)> {
    let root = crate::module::modules_dir(config_root);
    let Ok(entries) = std::fs::read_dir(root) else { return Vec::new() };
    let mut out: Vec<(String, String)> = entries
        .filter_map(std::result::Result::ok)
        .filter(|e| e.path().is_dir())
        .filter_map(|e| {
            let id = e.file_name().to_str()?.to_string();
            let raw = std::fs::read_to_string(e.path().join("metadata.json")).ok()?;
            let meta: serde_json::Value = serde_json::from_str(&raw).ok()?;
            let version = meta.get("version").and_then(|v| v.as_str()).unwrap_or("?").to_string();
            Some((id, version))
        })
        .collect();
    out.sort();
    out
}

#[allow(clippy::unnecessary_wraps)]
pub(crate) fn list(ctx: &AppContext) -> Result<()> {
    let mods = installed(&ctx.config_root);
    if mods.is_empty() {
        tracing::info!("no modules installed");
    }
    for (id, version) in mods {
        tracing::info!("{id} {version}");
    }
    Ok(())
}

/// The infrastructure a usable v3 client needs: stdlib is the foundation,
/// the store installs modules, and manager provides the profile-menu settings
/// and recovery surface. They are independently useful management surfaces.
pub(super) const SYSTEM_MODULES: &[&str] = &["stdlib", "store", "manager"];

/// Enables Splash on a fresh install, installs any absent system module, and
/// refreshes any outdated store-managed one from the registry, so every
/// `apply` leaves a client that can manage itself over a current disk baseline.
/// Pending first-install defaults retry until enabled or explicitly cancelled.
/// The baseline is what actually runs
/// after a Spotify update: the new build changes the classmap key, which
/// shadows every localStorage record until the store re-remaps them, and the
/// window in between is served entirely from these copies.
///
/// Best-effort by design, like the classmap fetch beside it: an unreachable
/// vault or a failed download warns and leaves the rest of the apply to
/// proceed. Only links into the store tree are ever replaced; a developer's
/// real directory or a link into their own build output is never judged
/// against the registry. Deliberate user intent recorded in the local vault
/// wins over freshness: a module disabled while still installed stays off,
/// and a hand-pin (an enabled version below one still installed) stays
/// pinned; a `pkg delete` of a system module clears the installed flags and re-seeds,
/// because a client without its management surfaces cannot recover itself.
pub(crate) fn ensure_default_modules(ctx: &AppContext) {
    let paths = crate::module::ModulePaths::from_config_root(&ctx.config_root);
    let vault = match cached_vault(&ctx.config_root) {
        Ok(vault) => vault,
        Err(e) => {
            tracing::warn!("cannot check system modules against the registry: {e}");
            return;
        }
    };
    let intent = crate::module::vault::load(&paths.vault_path);
    let new_install = intent.as_ref().is_ok_and(|vault| vault.modules.is_empty())
        && installed(&ctx.config_root).is_empty();
    let mut intent = intent.unwrap_or_else(|e| {
        tracing::warn!(
            "cannot read {}: {e}; refreshing without local intent",
            paths.vault_path.display()
        );
        crate::module::vault::Vault::default()
    });
    if new_install {
        let _ = intent.pending_defaults.insert("spicetify-splash".to_string());
        if let Err(e) = crate::module::vault::save(&paths.vault_path, &intent) {
            tracing::warn!("cannot save initial module selection: {e}");
            return;
        }
    }
    let pending_intent = crate::module::vault::Vault::default();
    for id in
        SYSTEM_MODULES.iter().copied().chain(intent.pending_defaults.iter().map(String::as_str))
    {
        let local = if intent.pending_defaults.contains(id) { &pending_intent } else { &intent };
        match plan_refresh(&paths, local, &vault, id, RefreshPolicy::Recover) {
            Ok(Refresh::Stage { target, superseded }) => {
                if let Err(e) =
                    stage_refresh(ctx, &paths, id, &target, superseded.as_deref(), &vault)
                {
                    tracing::warn!("could not stage default module {id}@{target}: {e}");
                }
            }
            Ok(Refresh::Skip(_)) => {
                if intent.pending_defaults.contains(id)
                    && let Err(e) = crate::module::vault::mutate(&paths.vault_path, |vault| {
                        vault.pending_defaults.remove(id)
                    })
                {
                    tracing::warn!("cannot clear initial module selection for {id}: {e}");
                }
            }
            Err(e) => tracing::warn!("cannot refresh default module {id}: {e}"),
        }
    }
}

/// Which caller a refresh serves; each treats missing modules, local intent and
/// registry gaps its own way.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum RefreshPolicy {
    /// `apply`: seed absent system modules and never override local intent.
    Recover,
    /// `pkg update`: every installed module, skipping anything it can't judge.
    UpdateAll,
    /// `pkg update <id>`: the user named this module, so an inferred pin gives way.
    UpdateNamed,
}

/// Why a refresh leaves a module as it is.
#[derive(Debug, PartialEq, Eq)]
enum Skip {
    /// Installed but not enabled.
    Disabled,
    /// Enabled at an older version while a newer one is installed.
    HandPinned { enabled: String },
    /// A developer's real directory or a link outside the store tree.
    NotStoreManaged,
    /// The registry doesn't carry this module.
    NotInRegistry,
    /// The installed version came from an explicit artifact, not the registry.
    ExplicitArtifact,
    /// Already at the registry's version.
    Current,
}

impl std::fmt::Display for Skip {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Disabled => f.write_str("disabled"),
            Self::HandPinned { enabled } => write!(f, "pinned to {enabled}"),
            Self::NotStoreManaged => f.write_str("not managed by the store"),
            Self::NotInRegistry => f.write_str("not in the registry"),
            Self::ExplicitArtifact => f.write_str("installed from an explicit artifact"),
            Self::Current => f.write_str("already up to date"),
        }
    }
}

/// What a registry refresh does with one module.
#[derive(Debug, PartialEq, Eq)]
enum Refresh {
    /// Install `target`, then collect the store copy of `superseded`.
    Stage { target: String, superseded: Option<String> },
    /// Leave the module as it is.
    Skip(Skip),
}

/// Decides one module's refresh against the registry. Only store-managed
/// installs are ever replaced: a developer's real directory or a link into
/// their own build output is never judged against the registry.
fn plan_refresh(
    paths: &crate::module::ModulePaths,
    intent: &crate::module::vault::Vault,
    vault: &Vault,
    id: &str,
    policy: RefreshPolicy,
) -> Result<Refresh> {
    let local = intent.modules.get(id);
    let present = paths.modules_root.join(id).exists();
    match local.and_then(local_intent) {
        Some(Skip::Disabled) => return Ok(Refresh::Skip(Skip::Disabled)),
        Some(pinned @ Skip::HandPinned { .. }) if policy != RefreshPolicy::UpdateNamed => {
            return Ok(Refresh::Skip(pinned));
        }
        _ => {}
    }
    if !present && policy != RefreshPolicy::Recover {
        anyhow::bail!("{id} is not installed");
    }
    let installed = store_managed_version(&paths.modules_root, &paths.store_root, id);
    if present && installed.is_none() {
        return Ok(Refresh::Skip(Skip::NotStoreManaged));
    }
    let Some(module) = vault.modules.get(id) else {
        if policy == RefreshPolicy::UpdateAll {
            return Ok(Refresh::Skip(Skip::NotInRegistry));
        }
        anyhow::bail!("{id} is not in the registry");
    };
    if policy == RefreshPolicy::UpdateAll
        && let Some(version) = installed.as_deref()
        && from_explicit_artifact(local, module, version)
    {
        return Ok(Refresh::Skip(Skip::ExplicitArtifact));
    }
    let target = resolve_version(module)?;
    if !should_stage(present, installed.as_deref(), &target, !module.enabled.is_empty()) {
        return Ok(Refresh::Skip(Skip::Current));
    }
    Ok(Refresh::Stage { superseded: installed.filter(|old| old != &target), target })
}

/// Whether the installed `version` came from bytes other than the registry's,
/// which a bulk update must not overwrite. Registry and store installs record
/// the registry's checksum; an install from an explicit URL records none. A
/// version the registry lists without a checksum is not evidence of either,
/// and one it doesn't list is judged by whether a checksum was recorded.
fn from_explicit_artifact(
    local: Option<&crate::module::vault::Module>,
    module: &VaultModule,
    version: &str,
) -> bool {
    let Some(store) = local.and_then(|local| local.versions.get(version)) else { return false };
    match module.v.get(version) {
        Some(entry) => {
            !entry.checksum.is_empty()
                && crate::module::normalize_checksum(&entry.checksum)
                    != crate::module::normalize_checksum(&store.checksum)
        }
        None => store.checksum.is_empty(),
    }
}

/// Installs and enables `id@target`, then collects the superseded store copy,
/// which would otherwise sit in the store tree forever, a megabyte per release.
fn stage_refresh(
    ctx: &AppContext,
    paths: &crate::module::ModulePaths,
    id: &str,
    target: &str,
    superseded: Option<&str>,
    vault: &Vault,
) -> Result<()> {
    let Some(entry) = vault.modules.get(id).and_then(|module| module.v.get(target)) else {
        anyhow::bail!("{id}@{target} is not in the registry");
    };
    stage_module_version(ctx, id, target, entry)?;
    if let Some(old) = superseded {
        collect_superseded(paths, id, old);
    }
    Ok(())
}

/// Deletes the store copy of `id@old`, warning rather than failing: the new
/// version is already enabled, and a leftover copy only costs disk space.
pub(super) fn collect_superseded(paths: &crate::module::ModulePaths, id: &str, old: &str) {
    match crate::module::vault::StoreIdentifier::parse(&format!("{id}@{old}")) {
        Ok(old) => {
            if let Err(e) = crate::module::delete(paths, &old) {
                tracing::warn!("could not collect superseded {old}: {e}");
            }
        }
        Err(e) => tracing::warn!("cannot collect invalid superseded package {id}@{old}: {e}"),
    }
}

/// The intent the local vault records for a module, if any refresh must honour
/// it: disabled while still installed, or enabled at a version below one that
/// is still installed (the only way a downgrade comes about by hand). Versions
/// a refresh already collected are no longer installed and don't count, so a
/// registry rollback doesn't leave a module looking pinned. A deleted module
/// has no installed versions left and is fair game.
fn local_intent(module: &crate::module::vault::Module) -> Option<Skip> {
    let has_installed = module.versions.values().any(|store| store.installed);
    match &module.enabled {
        None => has_installed.then_some(Skip::Disabled),
        Some(pin) => {
            let parsed = semver::Version::parse(pin).ok()?;
            module
                .versions
                .iter()
                .filter(|(_, store)| store.installed)
                .filter_map(|(v, _)| semver::Version::parse(v).ok())
                .any(|v| v > parsed)
                .then(|| Skip::HandPinned { enabled: pin.clone() })
        }
    }
}

/// The version behind `modules_root/<id>` when it is a store-managed link:
/// such a link resolves into `store/<id>/<version>`, so the resolved
/// directory name is the version. Anything else (a real directory, a link
/// into a developer's build output, a dangling link) resolves elsewhere or
/// not at all and yields `None`.
pub(super) fn store_managed_version(
    modules_root: &Path,
    store_root: &Path,
    id: &str,
) -> Option<String> {
    let resolved = std::fs::canonicalize(modules_root.join(id)).ok()?;
    let store = std::fs::canonicalize(store_root.join(id)).ok()?;
    if !resolved.starts_with(&store) {
        return None;
    }
    Some(resolved.file_name()?.to_str()?.to_string())
}

/// Whether the registry's `target` should replace what is on disk: an absent
/// module is always staged; a store-managed one for a strictly newer semver,
/// or for any different version when the registry pins `target` (a pin is a
/// maintainer rolling a bad release back, the one case where moving
/// backwards is right). `installed: None` on a present module is not
/// store-managed and is never replaced.
fn should_stage(present: bool, installed: Option<&str>, target: &str, target_pinned: bool) -> bool {
    if !present {
        return true;
    }
    let Some(installed) = installed else { return false };
    match (semver::Version::parse(target), semver::Version::parse(installed)) {
        (Ok(target), Ok(installed)) => {
            if target_pinned {
                return target != installed;
            }
            target > installed
        }
        _ => false,
    }
}

fn stage_module_version(
    ctx: &AppContext,
    id: &str,
    version: &str,
    entry: &VaultVersion,
) -> Result<()> {
    if entry.artifacts.is_empty() {
        anyhow::bail!("{id}@{version} has no artifact");
    }
    let tag = format!("{id}@{version}");
    crate::module::install_from_vault(
        &ctx.config_root,
        &tag,
        entry.artifacts.clone(),
        entry.checksum.clone(),
    )?;
    crate::module::enable_module(&ctx.config_root, &tag)?;
    tracing::info!("staged {tag}");
    Ok(())
}

/// The checksum the registry recorded for `id@version`, if it carries that
/// version at all.
///
/// Callers that did not resolve the module themselves (the `spicetify://`
/// handler, and so anything in the client that reaches it) use this rather
/// than a checksum handed to them, so the bytes are held to what was
/// published rather than to whatever the caller claims they should hash to.
pub(crate) fn registry_checksum(
    config_root: &Path,
    identifier: &str,
    version: &str,
) -> Option<String> {
    checksum_via_cache(
        &vault_cache_path(config_root),
        std::time::SystemTime::now(),
        identifier,
        version,
        || fetch_vault_body(DEFAULT_VAULT),
    )
}

/// Looks `identifier@version` up in the cached registry, and in a fresh copy
/// when the cache doesn't list it: a version published since the cache was
/// written is missing from it. Fetches at most once.
fn checksum_via_cache(
    path: &Path,
    now: std::time::SystemTime,
    identifier: &str,
    version: &str,
    fetch: impl Fn() -> Result<String>,
) -> Option<String> {
    let lookup = |vault: &Vault| {
        let checksum = &vault.modules.get(identifier)?.v.get(version)?.checksum;
        (!checksum.is_empty()).then(|| checksum.clone())
    };
    let fetched = std::cell::Cell::new(false);
    let fetch = || {
        fetched.set(true);
        fetch()
    };
    if let Some(checksum) =
        vault_via_cache(path, VAULT_CACHE_TTL, now, fetch).ok().as_ref().and_then(lookup)
    {
        return Some(checksum);
    }
    if fetched.get() {
        return None;
    }
    lookup(&vault_via_cache(path, std::time::Duration::ZERO, now, fetch).ok()?)
}

pub(crate) fn install(ctx: &AppContext, identifier: &str) -> Result<()> {
    let vault = cached_vault(&ctx.config_root)?;
    let Some(module) = vault.modules.get(identifier) else {
        let near: Vec<String> =
            vault.modules.keys().filter(|k| k.contains(identifier)).take(3).cloned().collect();
        if near.is_empty() {
            anyhow::bail!("module not found in the vault: {identifier}");
        }
        anyhow::bail!(
            "module not found in the vault: {identifier} (did you mean: {}?)",
            near.join(", ")
        );
    };
    let version = resolve_version(module)?;
    let Some(entry) = module.v.get(&version) else {
        anyhow::bail!("{identifier}@{version} is not in the vault");
    };
    if entry.artifacts.is_empty() {
        anyhow::bail!("{identifier}@{version} has no artifact in the vault");
    }
    tracing::info!("found {identifier}@{version}");
    crate::module::install_from_vault(
        &ctx.config_root,
        &format!("{identifier}@{version}"),
        entry.artifacts.clone(),
        entry.checksum.clone(),
    )
}

/// `pkg update [id]`: refreshes one installed module, or every store-managed
/// one, to the registry's current version. The registry is fetched fresh,
/// falling back to the cache only when offline. Fails when any module could
/// not be updated, or when a named module was left as it is for a reason the
/// user has to act on.
pub(crate) fn update(ctx: &AppContext, target_id: Option<&str>) -> Result<()> {
    if let Some(id) = target_id
        && let Some((name, _)) = id.split_once('@')
    {
        anyhow::bail!(
            "pkg update takes a module id; to switch {name} to a specific version, run `spicetify pkg enable {id}`"
        );
    }
    let paths = crate::module::ModulePaths::from_config_root(&ctx.config_root);
    let intent = crate::module::vault::load(&paths.vault_path)
        .map_err(|e| anyhow::anyhow!("cannot read {}: {e}", paths.vault_path.display()))?;
    let (ids, policy) = match target_id {
        Some(id) => (vec![id.to_string()], RefreshPolicy::UpdateNamed),
        None => (
            installed(&ctx.config_root).into_iter().map(|(id, _)| id).collect(),
            RefreshPolicy::UpdateAll,
        ),
    };
    if ids.is_empty() {
        tracing::info!("no modules installed");
        return Ok(());
    }
    let vault = vault_via_cache(
        &vault_cache_path(&ctx.config_root),
        std::time::Duration::ZERO,
        std::time::SystemTime::now(),
        || fetch_vault_body(DEFAULT_VAULT),
    )?;
    let report = update_modules(&paths, &intent, &vault, &ids, policy, |id, target, superseded| {
        stage_refresh(ctx, &paths, id, target, superseded, &vault)
    });
    if report.updated > 0 {
        tracing::info!(
            "updated {} module(s); run `spicetify apply` to load them in Spotify",
            report.updated
        );
    } else if report.failures.is_empty() {
        tracing::info!("all modules are up to date");
    }
    if report.failures.is_empty() {
        return Ok(());
    }
    anyhow::bail!("could not update {}", report.failures.join("; "))
}

/// The outcome of an update run.
#[derive(Debug, Default, PartialEq, Eq)]
struct UpdateReport {
    updated: usize,
    failures: Vec<String>,
}

/// Plans and stages each module, logging what happened. A named module left
/// as it is for a reason the user has to act on counts as a failure.
fn update_modules(
    paths: &crate::module::ModulePaths,
    intent: &crate::module::vault::Vault,
    vault: &Vault,
    ids: &[String],
    policy: RefreshPolicy,
    mut stage: impl FnMut(&str, &str, Option<&str>) -> Result<()>,
) -> UpdateReport {
    let mut report = UpdateReport::default();
    for id in ids {
        match plan_refresh(paths, intent, vault, id, policy) {
            Ok(Refresh::Stage { target, superseded }) => {
                match stage(id, &target, superseded.as_deref()) {
                    Ok(()) => {
                        report.updated += 1;
                        if let Some(old) = &superseded {
                            tracing::info!("updated {id}: {old} -> {target}");
                        } else {
                            tracing::info!("updated {id} to {target}");
                        }
                    }
                    Err(e) => report.failures.push(format!("{id}@{target}: {e}")),
                }
            }
            Ok(Refresh::Skip(Skip::Current)) => tracing::info!("{id}: {}", Skip::Current),
            Ok(Refresh::Skip(Skip::Disabled)) if policy == RefreshPolicy::UpdateNamed => {
                report.failures.push(format!(
                    "{id}: disabled; run `spicetify pkg enable {id}@<version>` to turn it back on"
                ));
            }
            Ok(Refresh::Skip(Skip::NotStoreManaged)) if policy == RefreshPolicy::UpdateNamed => {
                report.failures.push(format!(
                    "{id}: {}, so it is never replaced from the registry",
                    Skip::NotStoreManaged
                ));
            }
            Ok(Refresh::Skip(reason)) => tracing::info!("{id}: {reason}, left as is"),
            Err(e) => report.failures.push(format!("{id}: {e}")),
        }
    }
    report
}

#[cfg(test)]
mod tests {
    use super::*;

    fn module(enabled: &str, versions: &[&str]) -> VaultModule {
        VaultModule {
            enabled: enabled.to_string(),
            v: versions
                .iter()
                .map(|v| {
                    (
                        (*v).to_string(),
                        VaultVersion { artifacts: vec!["a".into()], checksum: String::new() },
                    )
                })
                .collect(),
        }
    }

    #[test]
    fn prefers_the_pinned_version() {
        let m = module("1.0.0", &["1.0.0", "2.0.0"]);
        assert_eq!(resolve_version(&m).expect("resolves"), "1.0.0");
    }

    #[test]
    fn falls_back_to_the_highest_version() {
        let m = module("", &["0.1.0", "0.2.0"]);
        assert_eq!(resolve_version(&m).expect("resolves"), "0.2.0");
    }

    #[test]
    fn ranks_versions_by_semver_not_key_order() {
        let m = module("", &["1.7.0", "1.10.0", "1.2.0"]);
        assert_eq!(resolve_version(&m).expect("resolves"), "1.10.0");
    }

    #[test]
    fn stages_absent_and_outdated_store_managed_modules() {
        assert!(should_stage(false, None, "1.10.0", false), "absent is always seeded");
        assert!(should_stage(true, Some("1.5.2"), "1.10.0", false), "stale baseline refreshes");
    }

    #[test]
    fn leaves_current_and_developer_installs_alone() {
        assert!(!should_stage(true, Some("1.10.0"), "1.10.0", false), "current stays");
        assert!(
            !should_stage(true, Some("1.11.0"), "1.10.0", false),
            "ahead of the registry stays"
        );
        assert!(!should_stage(true, None, "1.10.0", false), "a real directory is a dev build");
        assert!(
            !should_stage(true, Some("not-semver"), "1.10.0", false),
            "garbage is not evidence"
        );
    }

    #[test]
    fn the_vault_cache_short_circuits_refreshes_and_falls_back() {
        use std::time::{Duration, SystemTime};
        let dir = std::env::temp_dir().join(format!("spicetify-vaultcache-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("temp dir");
        let path = dir.join("vault.json");
        let ttl = Duration::from_secs(300);
        let body = |id: &str| format!(r#"{{"modules":{{"{id}":{{"v":{{"1.0.0":{{}}}}}}}}}}"#);

        std::fs::write(&path, body("cached")).expect("seed cache");
        let now = SystemTime::now();

        let fresh = vault_via_cache(&path, ttl, now, || panic!("a fresh cache must not fetch"))
            .expect("served from cache");
        assert!(fresh.modules.contains_key("cached"));

        let later = now + Duration::from_secs(600);
        let refreshed =
            vault_via_cache(&path, ttl, later, || Ok(body("fetched"))).expect("refetched");
        assert!(refreshed.modules.contains_key("fetched"));
        assert!(
            std::fs::read_to_string(&path).expect("cache file").contains("fetched"),
            "a successful fetch rewrites the cache"
        );

        let offline = vault_via_cache(&path, ttl, later + Duration::from_secs(600), || {
            Err(anyhow::anyhow!("network down"))
        })
        .expect("stale fallback");
        assert!(offline.modules.contains_key("fetched"), "a failed fetch serves the stale copy");

        let missing = dir.join("absent.json");
        assert!(
            vault_via_cache(&missing, ttl, later, || Err(anyhow::anyhow!("network down"))).is_err(),
            "no cache and no network is an error"
        );

        std::fs::write(&path, "not json").expect("corrupt cache");
        let repaired = vault_via_cache(&path, ttl, SystemTime::now(), || Ok(body("repaired")))
            .expect("corrupt cache refetches even while fresh");
        assert!(repaired.modules.contains_key("repaired"));

        std::fs::remove_dir_all(&dir).expect("cleanup");
    }

    #[test]
    fn a_checksum_lookup_refetches_when_the_cache_predates_the_version() {
        use std::time::SystemTime;
        let dir = std::env::temp_dir().join(format!("spicetify-checksum-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("temp dir");
        let path = dir.join("vault.json");
        let body = |versions: &str| format!(r#"{{"modules":{{"stdlib":{{"v":{{{versions}}}}}}}}}"#);
        let old = r#""1.0.0":{"checksum":"sha256:old"}"#;
        let both = format!(r#"{old},"1.1.0":{{"checksum":"sha256:new"}}"#);
        std::fs::write(&path, body(old)).expect("seed cache");
        let now = SystemTime::now();
        let lookup = |version: &str, fetch: &dyn Fn() -> Result<String>| {
            checksum_via_cache(&path, now, "stdlib", version, fetch)
        };

        assert_eq!(
            lookup("1.0.0", &|| panic!("a cached version must not fetch")).as_deref(),
            Some("sha256:old")
        );
        assert_eq!(
            lookup("1.1.0", &|| Ok(body(&both))).as_deref(),
            Some("sha256:new"),
            "a version newer than the cache is found in a fresh copy"
        );
        assert!(std::fs::read_to_string(&path).expect("cache").contains("sha256:new"));
        let fetches = std::cell::Cell::new(0);
        let counting = || {
            fetches.set(fetches.get() + 1);
            Ok(body(&both))
        };
        assert_eq!(lookup("9.9.9", &counting), None, "a version nobody published");
        assert_eq!(fetches.get(), 1, "a fresh cache that lacks it fetches once");
        let stale = now + std::time::Duration::from_secs(600);
        assert_eq!(checksum_via_cache(&path, stale, "stdlib", "9.9.9", counting), None);
        assert_eq!(fetches.get(), 2, "a stale cache is refetched once, not twice");
        std::fs::write(&path, body(old)).expect("reseed cache");
        assert_eq!(
            lookup("1.1.0", &|| Err(anyhow::anyhow!("network down"))),
            None,
            "offline, a version the cache lacks stays unverified"
        );
        std::fs::remove_dir_all(&dir).expect("cleanup");
    }

    #[test]
    fn a_registry_pin_moves_the_install_in_either_direction() {
        assert!(should_stage(true, Some("1.10.1"), "1.10.0", true), "a pin is a rollback signal");
        assert!(!should_stage(true, Some("1.10.0"), "1.10.0", true), "already on the pin");
    }

    fn intent(enabled: Option<&str>, versions: &[(&str, bool)]) -> crate::module::vault::Module {
        crate::module::vault::Module {
            enabled: enabled.map(str::to_string),
            versions: versions
                .iter()
                .map(|(v, installed)| {
                    (
                        (*v).to_string(),
                        crate::module::Store {
                            installed: *installed,
                            artifacts: Vec::new(),
                            checksum: String::new(),
                        },
                    )
                })
                .collect(),
        }
    }

    /// A config root with a store-managed `lyrics@1.0.0`, a disabled
    /// store-managed `off@1.0.0` and a developer's real `dev` directory.
    fn update_fixture(
        name: &str,
    ) -> (std::path::PathBuf, crate::module::ModulePaths, crate::module::vault::Vault, Vault) {
        let root =
            std::env::temp_dir().join(format!("spicetify-update-{name}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        let paths = crate::module::ModulePaths::from_config_root(&root);
        for id in [
            "lyrics",
            "off",
            "orphan",
            "url",
            "pinned",
            "yanked",
            "mirror",
            "fork",
            "unchecksummed",
        ] {
            std::fs::create_dir_all(paths.store_root.join(id).join("1.0.0")).expect("store copy");
            std::fs::create_dir_all(&paths.modules_root).expect("modules root");
            crate::util::link::create_dir_link(
                &paths.store_root.join(id).join("1.0.0"),
                &paths.modules_root.join(id),
            )
            .expect("store link");
        }
        std::fs::create_dir_all(paths.modules_root.join("dev")).expect("developer build");
        let mut local = crate::module::vault::Vault::default();
        assert!(
            local.modules.insert("off".to_string(), intent(None, &[("1.0.0", true)])).is_none()
        );
        let mut url = intent(Some("1.0.0"), &[("1.0.0", true)]);
        url.versions.get_mut("1.0.0").expect("version").checksum = String::new();
        url.versions.get_mut("1.0.0").expect("version").artifacts =
            vec!["https://example.invalid/fork.zip".to_string()];
        assert!(local.modules.insert("url".to_string(), url).is_none());
        let mut mirror = intent(Some("1.0.0"), &[("1.0.0", true)]);
        let store = mirror.versions.get_mut("1.0.0").expect("version");
        store.checksum = "MIRROR".to_string();
        store.artifacts = vec!["https://mirror.invalid/m.zip".to_string()];
        assert!(local.modules.insert("mirror".to_string(), mirror).is_none());
        for (id, checksum) in
            [("yanked", "sha256:gone"), ("fork", ""), ("unchecksummed", "sha256:old")]
        {
            let mut module = intent(Some("1.0.0"), &[("1.0.0", true)]);
            module.versions.get_mut("1.0.0").expect("version").checksum = checksum.to_string();
            assert!(local.modules.insert(id.to_string(), module).is_none());
        }
        let pinned = intent(Some("1.0.0"), &[("1.0.0", true), ("1.1.0", true)]);
        assert!(local.modules.insert("pinned".to_string(), pinned).is_none());
        let entry = || VaultVersion {
            artifacts: vec!["https://example.invalid/m.zip".to_string()],
            checksum: String::new(),
        };
        let module = |versions: &[&str]| VaultModule {
            enabled: String::new(),
            v: versions.iter().map(|v| ((*v).to_string(), entry())).collect(),
        };
        let vault = Vault {
            modules: BTreeMap::from([
                ("lyrics".to_string(), module(&["1.0.0", "1.1.0"])),
                ("off".to_string(), module(&["1.1.0"])),
                ("dev".to_string(), module(&["2.0.0"])),
                ("url".to_string(), module(&["1.0.0", "1.1.0"])),
                ("absent".to_string(), module(&["1.0.0"])),
                ("pinned".to_string(), module(&["1.0.0", "1.1.0", "1.2.0"])),
            ]),
        };
        let mut vault = vault;
        let checksummed = |checksum: &str| VaultVersion {
            artifacts: vec![
                "https://example.invalid/m.zip".to_string(),
                "https://mirror.invalid/m.zip".to_string(),
            ],
            checksum: checksum.to_string(),
        };
        assert!(
            vault
                .modules
                .get_mut("url")
                .expect("url")
                .v
                .insert("1.0.0".to_string(), checksummed("sha256:registry"))
                .is_some()
        );
        let mirror = VaultModule {
            enabled: String::new(),
            v: BTreeMap::from([
                ("1.0.0".to_string(), checksummed("sha256:mirror")),
                ("1.1.0".to_string(), checksummed("sha256:next")),
            ]),
        };
        assert!(vault.modules.insert("mirror".to_string(), mirror).is_none());
        assert!(vault.modules.insert("yanked".to_string(), module(&["1.1.0"])).is_none());
        assert!(vault.modules.insert("fork".to_string(), module(&["1.1.0"])).is_none());
        let unchecksummed = module(&["1.0.0", "1.1.0"]);
        assert!(vault.modules.insert("unchecksummed".to_string(), unchecksummed).is_none());
        (root, paths, local, vault)
    }

    #[test]
    fn each_refresh_policy_judges_modules_its_own_way() {
        let (root, paths, intent, vault) = update_fixture("plan");
        let plan = |id: &str, policy| plan_refresh(&paths, &intent, &vault, id, policy);
        let stage = |target: &str, superseded: Option<&str>| Refresh::Stage {
            target: target.to_string(),
            superseded: superseded.map(str::to_string),
        };
        use RefreshPolicy::{Recover, UpdateAll, UpdateNamed};

        assert_eq!(plan("lyrics", UpdateAll).expect("plan"), stage("1.1.0", Some("1.0.0")));
        assert_eq!(plan("dev", UpdateAll).expect("plan"), Refresh::Skip(Skip::NotStoreManaged));
        assert_eq!(plan("off", UpdateNamed).expect("plan"), Refresh::Skip(Skip::Disabled));

        assert_eq!(plan("orphan", UpdateAll).expect("plan"), Refresh::Skip(Skip::NotInRegistry));
        let error =
            plan("orphan", UpdateNamed).expect_err("named module missing from the registry");
        assert!(error.to_string().contains("orphan is not in the registry"), "{error}");

        assert_eq!(plan("url", UpdateAll).expect("plan"), Refresh::Skip(Skip::ExplicitArtifact));
        assert_eq!(plan("url", UpdateNamed).expect("plan"), stage("1.1.0", Some("1.0.0")));
        assert_eq!(
            plan("mirror", UpdateAll).expect("plan"),
            stage("1.1.0", Some("1.0.0")),
            "a registry install with other artifacts and checksum spelling updates"
        );
        assert_eq!(
            plan("yanked", UpdateAll).expect("plan"),
            stage("1.1.0", Some("1.0.0")),
            "a registry install the registry no longer lists updates"
        );
        assert_eq!(
            plan("fork", UpdateAll).expect("plan"),
            Refresh::Skip(Skip::ExplicitArtifact),
            "a URL install of a version the registry doesn't list stays"
        );
        assert_eq!(
            plan("unchecksummed", UpdateAll).expect("plan"),
            stage("1.1.0", Some("1.0.0")),
            "a registry entry without a checksum is no evidence of an explicit install"
        );

        assert_eq!(
            plan("pinned", UpdateAll).expect("plan"),
            Refresh::Skip(Skip::HandPinned { enabled: "1.0.0".to_string() })
        );
        assert_eq!(
            plan("pinned", UpdateNamed).expect("plan"),
            stage("1.2.0", Some("1.0.0")),
            "naming the module overrides an inferred pin"
        );
        assert_eq!(
            plan("pinned", Recover).expect("plan"),
            Refresh::Skip(Skip::HandPinned { enabled: "1.0.0".to_string() })
        );

        assert_eq!(
            plan("absent", Recover).expect("plan"),
            stage("1.0.0", None),
            "apply seeds absent modules"
        );
        let error = plan("absent", UpdateNamed).expect_err("not installed");
        assert!(error.to_string().contains("absent is not installed"), "{error}");
        std::fs::remove_dir_all(&root).expect("cleanup");
    }

    #[test]
    fn a_bulk_update_skips_what_it_cannot_judge_and_reports_real_failures() {
        let (root, paths, intent, vault) = update_fixture("bulk");
        let ids: Vec<String> = ["dev", "lyrics", "orphan", "pinned", "url"]
            .iter()
            .map(|id| (*id).to_string())
            .collect();
        let mut staged = Vec::new();
        let report = update_modules(
            &paths,
            &intent,
            &vault,
            &ids,
            RefreshPolicy::UpdateAll,
            |id, target, superseded| {
                staged.push(format!("{id}@{target} replacing {superseded:?}"));
                anyhow::bail!("download failed")
            },
        );
        assert_eq!(staged, ["lyrics@1.1.0 replacing Some(\"1.0.0\")"]);
        assert_eq!(
            report,
            UpdateReport {
                updated: 0,
                failures: vec!["lyrics@1.1.0: download failed".to_string()]
            }
        );

        let report =
            update_modules(&paths, &intent, &vault, &ids, RefreshPolicy::UpdateAll, |_, _, _| {
                Ok(())
            });
        assert_eq!(report, UpdateReport { updated: 1, failures: Vec::new() });
        std::fs::remove_dir_all(&root).expect("cleanup");
    }

    #[test]
    fn a_named_update_fails_when_the_user_has_to_act() {
        let (root, paths, intent, vault) = update_fixture("named");
        let named = |id: &str| {
            update_modules(
                &paths,
                &intent,
                &vault,
                &[id.to_string()],
                RefreshPolicy::UpdateNamed,
                |_, _, _| Ok(()),
            )
        };
        assert!(named("off").failures[0].contains("run `spicetify pkg enable off@<version>`"));
        assert!(named("dev").failures[0].contains("never replaced from the registry"));
        assert!(named("ghost").failures[0].contains("ghost is not installed"));
        assert_eq!(named("pinned"), UpdateReport { updated: 1, failures: Vec::new() });
        std::fs::remove_dir_all(&root).expect("cleanup");
    }

    #[test]
    fn honours_disable_and_hand_pins_but_not_deletion() {
        assert!(
            local_intent(&intent(None, &[("1.10.0", true)])) == Some(Skip::Disabled),
            "disabled while installed stays off"
        );
        assert!(
            local_intent(&intent(None, &[("1.10.0", false)])).is_none(),
            "a deleted module is recovery, not intent"
        );
        assert!(
            matches!(
                local_intent(&intent(Some("1.7.0"), &[("1.7.0", true), ("1.10.0", true)])),
                Some(Skip::HandPinned { .. })
            ),
            "an enabled version below an installed newer one is a hand pin"
        );
        assert!(
            local_intent(&intent(Some("1.10.0"), &[("1.10.0", true)])).is_none(),
            "enabled at the newest installed version is the normal state"
        );
        assert!(
            local_intent(&intent(Some("1.0.0"), &[("1.0.0", true), ("1.1.0", false)])).is_none(),
            "a version a registry rollback already collected is not a hand pin"
        );
    }

    #[test]
    fn rejects_a_pin_that_is_not_in_the_vault() {
        let m = module("9.9.9", &["1.0.0"]);
        assert!(resolve_version(&m).is_err());
    }

    #[test]
    fn rejects_an_empty_vault_entry() {
        assert!(resolve_version(&module("", &[])).is_err());
    }

    fn defaults_fixture(name: &str) -> (std::path::PathBuf, AppContext) {
        let root =
            std::env::temp_dir().join(format!("spicetify-defaults-{name}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        let mut modules = serde_json::Map::new();
        for id in ["stdlib", "store", "manager", "spicetify-splash"] {
            let artifact = root.join("artifacts").join(id);
            std::fs::create_dir_all(&artifact).expect("artifact directory");
            std::fs::write(
                artifact.join("metadata.json"),
                serde_json::json!({ "name": id, "version": "1.0.0" }).to_string(),
            )
            .expect("artifact metadata");
            drop(modules.insert(
                id.to_string(),
                serde_json::json!({ "v": { "1.0.0": { "artifacts": [artifact] } } }),
            ));
        }
        let cache = vault_cache_path(&root);
        std::fs::create_dir_all(cache.parent().expect("cache parent")).expect("cache directory");
        std::fs::write(cache, serde_json::json!({ "modules": modules }).to_string())
            .expect("cached registry");
        let ctx = AppContext::from_config(root.clone(), &crate::context::Config::default())
            .expect("context");
        (root, ctx)
    }

    #[test]
    fn fresh_installs_enable_splash_and_keep_disable_and_delete_choices() {
        for initialized in [false, true] {
            let (root, ctx) = defaults_fixture(if initialized { "initialized" } else { "fresh" });
            let paths = crate::module::ModulePaths::from_config_root(&root);
            if initialized {
                crate::module::initialize(&paths).expect("initialize");
            }
            ensure_default_modules(&ctx);
            let splash = paths.modules_root.join("spicetify-splash");
            assert!(splash.join("metadata.json").is_file(), "Splash is installed and enabled");
            let local = crate::module::vault::load(&paths.vault_path).expect("local vault");
            assert_eq!(
                local.modules.get("spicetify-splash").expect("Splash record").enabled.as_deref(),
                Some("1.0.0")
            );
            assert!(local.pending_defaults.is_empty(), "successful setup clears pending defaults");

            let disabled = crate::module::parse_enable_id("spicetify-splash@").expect("disable id");
            crate::module::enable(&paths, &disabled).expect("disable Splash");
            ensure_default_modules(&ctx);
            assert!(!splash.exists(), "Apply keeps Splash disabled");
            let local = crate::module::vault::load(&paths.vault_path).expect("local vault");
            assert!(
                local.modules.get("spicetify-splash").expect("Splash record").enabled.is_none()
            );

            crate::module::enable_module(&root, "spicetify-splash@1.0.0").expect("enable Splash");
            assert!(splash.exists(), "Splash can be enabled again");
            crate::module::delete_module(&root, "spicetify-splash@1.0.0").expect("delete Splash");
            ensure_default_modules(&ctx);
            assert!(!splash.exists(), "Apply keeps Splash removed");
            std::fs::remove_dir_all(root).expect("cleanup");
        }
    }

    #[test]
    fn existing_installs_do_not_gain_splash() {
        for managed in [false, true] {
            let (root, ctx) = defaults_fixture(if managed { "managed" } else { "developer" });
            let paths = crate::module::ModulePaths::from_config_root(&root);
            if managed {
                install(&ctx, "stdlib").expect("install an existing module");
                crate::module::enable_module(&root, "stdlib@1.0.0").expect("enable stdlib");
            } else {
                let existing = paths.modules_root.join("local-module");
                std::fs::create_dir_all(&existing).expect("local module directory");
                std::fs::write(
                    existing.join("metadata.json"),
                    r#"{"name":"Local module","version":"1.0.0"}"#,
                )
                .expect("local module metadata");
            }
            ensure_default_modules(&ctx);
            assert!(paths.modules_root.join("manager").exists(), "management still bootstraps");
            assert!(!paths.modules_root.join("spicetify-splash").exists());
            std::fs::remove_dir_all(root).expect("cleanup");
        }
    }

    #[test]
    fn failed_initial_download_retries_unless_the_user_opts_out() {
        for action in ["retry", "disable", "delete"] {
            let (root, ctx) = defaults_fixture(action);
            let paths = crate::module::ModulePaths::from_config_root(&root);
            let cache = vault_cache_path(&root);
            let available = std::fs::read_to_string(&cache).expect("registry fixture");
            let mut unavailable: serde_json::Value =
                serde_json::from_str(&available).expect("registry JSON");
            *unavailable
                .pointer_mut("/modules/spicetify-splash/v/1.0.0/artifacts")
                .expect("Splash artifacts") =
                serde_json::json!(["http://127.0.0.1:0/unavailable.zip"]);
            std::fs::write(&cache, unavailable.to_string()).expect("unavailable artifact");
            ensure_default_modules(&ctx);
            assert!(paths.modules_root.join("manager").exists(), "core setup succeeded");
            assert!(!paths.modules_root.join("spicetify-splash").exists());
            let local = crate::module::vault::load(&paths.vault_path).expect("local vault");
            assert!(local.pending_defaults.contains("spicetify-splash"));
            assert!(
                !local
                    .modules
                    .get("spicetify-splash")
                    .expect("failed download record")
                    .versions
                    .get("1.0.0")
                    .expect("failed version")
                    .installed
            );
            match action {
                "disable" => {
                    let id =
                        crate::module::parse_enable_id("spicetify-splash@").expect("disable id");
                    crate::module::enable(&paths, &id).expect("cancel default installation");
                }
                "delete" => {
                    crate::module::delete_module(&root, "spicetify-splash@1.0.0")
                        .expect("remove pending default");
                }
                _ => {}
            }
            std::fs::write(cache, available).expect("restored artifact");
            ensure_default_modules(&ctx);
            assert_eq!(paths.modules_root.join("spicetify-splash").exists(), action == "retry");
            let local = crate::module::vault::load(&paths.vault_path).expect("local vault");
            assert!(local.pending_defaults.is_empty());
            std::fs::remove_dir_all(root).expect("cleanup");
        }
    }

    // Network-gated smoke test for the real seeding path: fetch the registry,
    // download each system module, verify its checksum, and enable it into a
    // throwaway config. Run with `cargo test -p spicetify --ignored seed_live`.
    #[test]
    #[ignore = "hits the live registry and downloads artifacts"]
    fn seed_live_installs_and_enables_system_modules() {
        let root = std::env::temp_dir().join(format!("spicetify-seed-live-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&root).expect("temp config");

        let vault = cached_vault(&root).expect("registry reachable");
        let ctx = AppContext::from_config(root.clone(), &crate::context::Config::default())
            .expect("context");
        for id in SYSTEM_MODULES {
            let module = vault.modules.get(*id).expect("registry carries every system module");
            let version = resolve_version(module).expect("resolvable");
            let entry = module.v.get(&version).expect("resolved version has an entry");
            let result = stage_module_version(&ctx, id, &version, entry);
            assert!(result.is_ok(), "seed {id}: {:?}", result.err());
        }

        let modules_root = crate::module::modules_dir(&root);
        for id in SYSTEM_MODULES {
            let link = modules_root.join(id);
            assert!(link.exists(), "{id} enabled and reachable through modules/");
            assert!(link.join("metadata.json").is_file(), "{id} unpacked with its metadata");
        }
        let paths = crate::module::ModulePaths::from_config_root(&root);
        for id in SYSTEM_MODULES {
            assert!(
                store_managed_version(&paths.modules_root, &paths.store_root, id).is_some(),
                "{id} is store-managed after seeding"
            );
        }

        std::fs::remove_dir_all(&root).expect("cleanup");
    }

    #[test]
    fn recognises_store_managed_installs_by_their_resolved_path() {
        let dir = std::env::temp_dir().join(format!("spicetify-managed-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let modules = dir.join("modules");
        let store = dir.join("store");
        std::fs::create_dir_all(modules.join("manager")).expect("real dir");
        std::fs::create_dir_all(store.join("stdlib").join("1.10.0")).expect("store copy");
        std::fs::create_dir_all(store.join("store")).expect("store dir without an install");
        std::fs::create_dir_all(dir.join("dist").join("store@dev")).expect("dev build");
        crate::util::link::create_dir_link(
            &store.join("stdlib").join("1.10.0"),
            &modules.join("stdlib"),
        )
        .expect("store link");
        crate::util::link::create_dir_link(
            &dir.join("dist").join("store@dev"),
            &modules.join("store"),
        )
        .expect("dev link");

        assert_eq!(store_managed_version(&modules, &store, "stdlib").as_deref(), Some("1.10.0"));
        assert_eq!(
            store_managed_version(&modules, &store, "manager"),
            None,
            "a real directory is a developer's build"
        );
        assert_eq!(
            store_managed_version(&modules, &store, "store"),
            None,
            "a link outside the store tree is a developer's build"
        );
        assert_eq!(
            store_managed_version(&modules, &store, "bookmark"),
            None,
            "absent resolves to nothing"
        );

        std::fs::remove_dir_all(&dir).expect("cleanup");
    }
}
