use std::borrow::Cow;

use url::Url;

use super::apply::ApplyMode;
use crate::context::AppContext;
use crate::error::Result;
use crate::fl;
use crate::module::{self, ModulePaths, Store};

pub(crate) fn run(ctx: &AppContext, uri: &str) -> Result<()> {
    let response = handle(ctx, uri, ApplyMode::Cli { no_cache: false })?;
    if !response.is_empty() {
        let outbound = format!("spotify:app:rpc:{response}");
        launch_uri(&outbound)?;
    }
    Ok(())
}

pub fn handle(ctx: &AppContext, uri: &str, apply_mode: ApplyMode) -> Result<String> {
    let u = Url::parse(uri).map_err(|_| anyhow::anyhow!(fl!("proxy-invalid-url")))?;
    if u.scheme() != "spicetify" {
        return Err(anyhow::anyhow!(fl!("unsupported-scheme")));
    }

    let opaque = u.path();
    let mut parts = opaque.split(':');
    let module_id = parts.next().unwrap_or_default();
    let action = parts.next().unwrap_or_default();

    let prefix = format!("spicetify:{module_id}:");
    let action = ProtocolAction::parse(action)
        .ok_or_else(|| anyhow::anyhow!(fl!("protocol-error", err = "unknown action")))?;
    perform(ctx, action, &u, apply_mode)?;

    if module_id == "0" {
        return Ok(String::new());
    }
    let mut response = prefix;
    response.push('1');
    Ok(response)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ProtocolAction {
    Add,
    FastInstall,
    FastEnable,
    Install,
    Enable,
    Delete,
    Remove,
    FastDelete,
    FastRemove,
    Apply,
    BlockUpdates,
    UnblockUpdates,
    EnableAutoUpdate,
    DisableAutoUpdate,
}

impl ProtocolAction {
    fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "add" => Self::Add,
            "fast-install" => Self::FastInstall,
            "fast-enable" => Self::FastEnable,
            "install" => Self::Install,
            "enable" => Self::Enable,
            "delete" => Self::Delete,
            "remove" => Self::Remove,
            "fast-delete" => Self::FastDelete,
            "fast-remove" => Self::FastRemove,
            "apply" => Self::Apply,
            "block-updates" => Self::BlockUpdates,
            "unblock-updates" => Self::UnblockUpdates,
            "enable-auto-update" => Self::EnableAutoUpdate,
            "disable-auto-update" => Self::DisableAutoUpdate,
            _ => return None,
        })
    }
}

fn perform(
    ctx: &AppContext,
    action: ProtocolAction,
    uri: &Url,
    apply_mode: ApplyMode,
) -> Result<()> {
    let _guard = match action {
        ProtocolAction::Apply | ProtocolAction::BlockUpdates | ProtocolAction::UnblockUpdates => {
            None
        }
        _ => Some(super::guard::try_acquire(&ctx.config_root)?),
    };
    let paths = ModulePaths::from_config_root(&ctx.config_root);
    let query: Vec<_> = uri.query_pairs().collect();

    match action {
        ProtocolAction::Add | ProtocolAction::FastInstall | ProtocolAction::FastEnable => {
            add_from_registry(ctx, &paths, &query, action)
        }
        ProtocolAction::Install => {
            let id = require_id(&query)?;
            module::install(&paths, &id)?;
            Ok(())
        }
        ProtocolAction::Enable => {
            let id = module::parse_enable_id(&require_param(&query, "id")?)?;
            // An empty version is the disable spelling: it drops the enable
            // link, which for the store is an uninstall by another name.
            if id.version().is_empty() {
                refuse_store_removal(&id)?;
            }
            module::enable(&paths, &id)?;
            Ok(())
        }
        ProtocolAction::Delete => {
            let id = require_id(&query)?;
            refuse_store_removal(&id)?;
            module::delete(&paths, &id)?;
            Ok(())
        }
        ProtocolAction::Remove => {
            let id = require_id(&query)?;
            refuse_store_removal(&id)?;
            module::remove_store(&paths, &id)?;
            Ok(())
        }
        ProtocolAction::FastDelete | ProtocolAction::FastRemove => {
            let id = require_id(&query)?;
            refuse_store_removal(&id)?;
            let disable_id = module::vault::StoreIdentifier::disabled(id.module_identifier())?;
            module::enable(&paths, &disable_id)?;
            module::delete(&paths, &id)?;
            if matches!(action, ProtocolAction::FastRemove) {
                module::remove_store(&paths, &id)?;
            }
            Ok(())
        }
        // apply stops and relaunches the client, so a caller inside it is
        // killed before any reply reaches it. That is expected: treat it as
        // fire-and-forget rather than waiting on a response.
        ProtocolAction::Apply => {
            let guard = super::guard::try_acquire(&ctx.config_root)?;
            super::apply::run(ctx, &guard, apply_mode)
        }
        ProtocolAction::BlockUpdates => {
            let _guard = super::guard::try_acquire(&ctx.config_root)?;
            set_updates_blocked(ctx, true)
        }
        ProtocolAction::UnblockUpdates => {
            let _guard = super::guard::try_acquire(&ctx.config_root)?;
            set_updates_blocked(ctx, false)
        }
        ProtocolAction::EnableAutoUpdate => super::self_update::set_auto(ctx, true),
        ProtocolAction::DisableAutoUpdate => super::self_update::set_auto(ctx, false),
    }
}

/// `add`, `fast-install` and `fast-enable`: record a store version, then
/// install it, then enable it, stopping after the step the action names.
fn add_from_registry(
    ctx: &AppContext,
    paths: &ModulePaths,
    query: &[(Cow<'_, str>, Cow<'_, str>)],
    action: ProtocolAction,
) -> Result<()> {
    let id = require_id(query)?;
    let artifacts = get_all_params(query, "artifacts");
    // The checksum comes from the registry, never from the caller.
    // Anything that can reach this handler (page JS through
    // Spicetify.Daemon, a spicetify:// link) could otherwise supply
    // the hash of its own bytes and have them verified against
    // themselves, which is no verification at all.
    let checksum = crate::commands::pkg::registry_checksum(
        &ctx.config_root,
        id.module_identifier(),
        id.version(),
    )
    .unwrap_or_default();
    if checksum.is_empty() {
        // For an ordinary module this degrades to an unverified
        // install with a warning. The system modules are refused
        // outright: replacing the store unverified is an uninstall
        // with extra steps, and the in-client stdlib update path
        // promises that disk staging is registry-verified. An
        // unreachable registry looks identical to an absent entry
        // here, and refusing is the right answer for both.
        if super::pkg::SYSTEM_MODULES.iter().any(|name| id.is_within_module(name)) {
            return Err(anyhow::anyhow!(fl!(
                "protocol-error",
                err = format!(
                    "{} can only be installed from a registry-verified artifact",
                    id.module_identifier()
                )
            )));
        }
        tracing::warn!(
            "{id}: not in the registry, so there is no checksum to verify these bytes against"
        );
    }
    let previous = super::pkg::store_managed_version(
        &paths.modules_root,
        &paths.store_root,
        id.module_identifier(),
    );
    module::add_store(paths, &id, Store { installed: false, artifacts, checksum })?;
    if matches!(action, ProtocolAction::Add) {
        return Ok(());
    }
    module::install(paths, &id)?;
    if matches!(action, ProtocolAction::FastInstall) {
        return Ok(());
    }
    module::enable(paths, &id)?;
    if let Some(old) = previous.filter(|old| old != id.version()) {
        super::pkg::collect_superseded(paths, id.module_identifier(), &old);
    }
    Ok(())
}

/// Changing the update policy patches Spotify's binary, which means stopping
/// the client; `set_blocked` leaves it stopped because a terminal caller
/// relaunches it themselves. A caller inside the client cannot, so bring it
/// back rather than having the user's Spotify vanish on a button press. A
/// no-op change never stops it, so only relaunch what was actually running.
fn set_updates_blocked(ctx: &AppContext, block: bool) -> Result<()> {
    let was_running = crate::lifecycle::is_running(ctx);
    super::updates::set_blocked(ctx, block)?;
    if was_running && !crate::lifecycle::is_running(ctx) {
        crate::lifecycle::start(ctx)?;
    }
    Ok(())
}

/// The store is the client's recovery surface: with it gone nothing can be
/// reinstalled from inside the client, so protocol callers (page JS through
/// the daemon socket, a `spicetify://` link) can never delete it. The
/// terminal commands stay able to, as does deleting files by hand.
fn refuse_store_removal(id: &module::vault::StoreIdentifier) -> Result<()> {
    if id.is_within_module("store") {
        return Err(anyhow::anyhow!(fl!(
            "protocol-error",
            err = "the store cannot be uninstalled"
        )));
    }
    Ok(())
}

fn require_id(query: &[(Cow<'_, str>, Cow<'_, str>)]) -> Result<module::vault::StoreIdentifier> {
    let raw = require_param(query, "id")?;
    Ok(module::vault::StoreIdentifier::parse(&raw)?)
}

fn require_param(query: &[(Cow<'_, str>, Cow<'_, str>)], key: &str) -> Result<String> {
    query
        .iter()
        .find(|(k, _)| k == key)
        .map(|(_, v)| v.to_string())
        .ok_or_else(|| anyhow::anyhow!("missing '{key}' query parameter"))
}

fn get_all_params(query: &[(Cow<'_, str>, Cow<'_, str>)], key: &str) -> Vec<String> {
    query.iter().filter(|(k, _)| k == key).map(|(_, v)| v.to_string()).collect()
}

fn launch_uri(uri: &str) -> Result<()> {
    opener::open(uri).map_err(|e| anyhow::anyhow!("failed to open URI '{uri}': {e}"))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn id(module: &str, version: &str) -> module::vault::StoreIdentifier {
        module::parse_enable_id(&format!("{module}@{version}")).expect("valid test ID")
    }

    #[test]
    fn refuses_removing_the_store_at_any_version() {
        assert!(refuse_store_removal(&id("store", "1.6.1")).is_err());
        assert!(refuse_store_removal(&id("store", "")).is_err());
        for name in ["STORE", "Store", "sToRe", "store/1.6.1", "STORE/1.6.1/nested"] {
            assert!(refuse_store_removal(&id(name, "1")).is_err(), "{name}");
        }
    }

    #[test]
    fn matches_the_store_id_exactly() {
        assert!(refuse_store_removal(&id("bookmark", "0.4.0")).is_ok());
        assert!(refuse_store_removal(&id("someone/store", "1.0.0")).is_ok());
        assert!(refuse_store_removal(&id("store-theme", "1.0.0")).is_ok());
    }

    #[test]
    fn automatic_updates_turn_off_and_on_through_the_protocol() -> Result<()> {
        let mut nonce = [0; 16];
        getrandom::fill(&mut nonce)?;
        let root =
            std::env::temp_dir().join(format!("spicetify-protocol-auto-{}", hex::encode(nonce)));
        std::fs::create_dir(&root)?;
        let ctx = AppContext::from_config(root.clone(), &crate::context::Config::default())?;
        let config = || crate::context::Config::load(&ctx.config_file);

        let reply = handle(&ctx, "spicetify:settings:disable-auto-update", ApplyMode::Daemon)?;
        assert_eq!(reply, "spicetify:settings:1", "the Manager waits for this reply");
        assert!(!config()?.auto_update);
        let _ = handle(&ctx, "spicetify:settings:enable-auto-update", ApplyMode::Daemon)?;
        assert!(config()?.auto_update);
        std::fs::remove_dir_all(&root)?;
        Ok(())
    }

    #[test]
    fn protocol_refuses_encoded_path_ids_before_package_actions() -> Result<()> {
        let mut nonce = [0; 16];
        getrandom::fill(&mut nonce)?;
        let root =
            std::env::temp_dir().join(format!("spicetify-protocol-path-{}", hex::encode(nonce)));
        std::fs::create_dir(&root)?;
        let ctx = AppContext::from_config(root.clone(), &crate::context::Config::default())?;
        for action in [
            "add",
            "install",
            "enable",
            "delete",
            "remove",
            "fast-install",
            "fast-enable",
            "fast-delete",
            "fast-remove",
        ] {
            for raw in ["../victim@1", "/victim@1", "module@..", "../victim@"] {
                let mut uri = Url::parse(&format!("spicetify:0:{action}"))?;
                let _ = uri.query_pairs_mut().append_pair("id", raw);
                let error = handle(&ctx, uri.as_str(), ApplyMode::Daemon)
                    .expect_err("unsafe IDs must be refused");
                assert!(error.to_string().contains("invalid store id"), "{action} {raw}: {error}");
                assert!(!root.join("modules").exists(), "validation must precede vault mutation");
            }
        }
        std::fs::remove_dir_all(&root)?;
        Ok(())
    }

    #[test]
    fn fast_enable_moves_stdlib_and_collects_the_copy_it_replaced() -> Result<()> {
        let mut nonce = [0; 16];
        getrandom::fill(&mut nonce)?;
        let root =
            std::env::temp_dir().join(format!("spicetify-protocol-swap-{}", hex::encode(nonce)));
        std::fs::create_dir_all(root.join("cache"))?;
        std::fs::write(
            root.join("cache/vault.json"),
            r#"{"modules":{"stdlib":{"v":{"1.1.0":{"checksum":"sha256:registry"}}}}}"#,
        )?;
        let build = root.join("build");
        std::fs::create_dir(&build)?;
        std::fs::write(build.join("metadata.json"), r#"{"version":"1.1.0"}"#)?;
        let ctx = AppContext::from_config(root.clone(), &crate::context::Config::default())?;
        let paths = ModulePaths::from_config_root(&root);
        let stage = |version: &str| -> Result<()> {
            let mut uri = Url::parse("spicetify:stdlib:fast-enable")?;
            let _ = uri
                .query_pairs_mut()
                .append_pair("id", &format!("stdlib@{version}"))
                .append_pair("artifacts", &build.to_string_lossy());
            let _ = handle(&ctx, uri.as_str(), ApplyMode::Daemon)?;
            Ok(())
        };
        std::fs::create_dir_all(paths.store_root.join("stdlib/1.0.0"))?;
        std::fs::create_dir_all(&paths.modules_root)?;
        crate::util::link::create_dir_link(
            &paths.store_root.join("stdlib/1.0.0"),
            &paths.modules_root.join("stdlib"),
        )?;
        let mut vault = module::vault::Vault::default();
        let _ = vault.modules.insert(
            "stdlib".to_string(),
            module::vault::Module {
                enabled: Some("1.0.0".to_string()),
                versions: std::collections::BTreeMap::from([(
                    "1.0.0".to_string(),
                    Store { installed: true, artifacts: Vec::new(), checksum: String::new() },
                )]),
            },
        );
        module::vault::save(&paths.vault_path, &vault)?;

        stage("1.1.0")?;
        assert!(paths.modules_root.join("stdlib/metadata.json").is_file(), "1.1.0 is linked");
        assert!(!paths.store_root.join("stdlib/1.0.0").exists(), "the replaced copy is collected");
        let saved = module::vault::load(&paths.vault_path)?;
        let stdlib = saved.modules.get("stdlib").expect("stdlib intent");
        assert_eq!(stdlib.enabled.as_deref(), Some("1.1.0"));
        assert_eq!(
            stdlib.versions.get("1.1.0").map(|s| s.checksum.as_str()),
            Some("sha256:registry")
        );

        stage("1.1.0")?;
        assert!(paths.modules_root.join("stdlib/metadata.json").is_file(), "restaging keeps it");
        std::fs::remove_dir_all(&root)?;
        Ok(())
    }

    #[test]
    fn protocol_protects_system_module_aliases_without_mutating_the_store() -> Result<()> {
        let mut nonce = [0; 16];
        getrandom::fill(&mut nonce)?;
        let root =
            std::env::temp_dir().join(format!("spicetify-protocol-alias-{}", hex::encode(nonce)));
        std::fs::create_dir(&root)?;
        // A fresh empty registry makes the unverified-install check offline.
        std::fs::create_dir(root.join("cache"))?;
        std::fs::write(root.join("cache/vault.json"), r#"{"modules":{}}"#)?;
        std::fs::create_dir_all(root.join("store/store/1"))?;
        std::fs::write(root.join("store/store/1/keep.txt"), "store payload")?;
        let ctx = AppContext::from_config(root.clone(), &crate::context::Config::default())?;
        for module in ["store", "STORE", "Store", "store/1", "STORE/1/nested"] {
            for action in ["delete", "remove", "fast-delete", "fast-remove", "enable"] {
                let version = if action == "enable" { "" } else { "1" };
                let mut uri = Url::parse(&format!("spicetify:0:{action}"))?;
                let _ = uri.query_pairs_mut().append_pair("id", &format!("{module}@{version}"));
                let error = handle(&ctx, uri.as_str(), ApplyMode::Daemon)
                    .expect_err("the Store must be protected");
                assert!(error.to_string().contains("cannot be uninstalled"), "{error}");
            }
        }
        for module in ["STORE", "sTdLiB", "Manager", "store/1", "STDLIB/1/nested"] {
            for action in ["add", "fast-install", "fast-enable"] {
                let mut uri = Url::parse(&format!("spicetify:0:{action}"))?;
                let _ = uri.query_pairs_mut().append_pair("id", &format!("{module}@1"));
                let error = handle(&ctx, uri.as_str(), ApplyMode::Daemon)
                    .expect_err("unverified system install");
                assert!(error.to_string().contains("registry-verified"), "{error}");
            }
        }
        assert!(root.join("store/store/1/keep.txt").is_file());
        assert!(!root.join("modules").exists());
        std::fs::remove_dir_all(&root)?;
        Ok(())
    }
}
