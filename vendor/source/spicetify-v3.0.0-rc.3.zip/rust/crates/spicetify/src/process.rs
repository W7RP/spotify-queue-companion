use std::process::{Command, Stdio};

use crate::context::AppContext;
use crate::error::Result;

#[cfg(windows)]
pub(crate) fn background_command(program: impl AsRef<std::ffi::OsStr>) -> Command {
    use std::os::windows::process::CommandExt;
    use windows::Win32::System::Threading::CREATE_NO_WINDOW;

    let mut command = Command::new(program);
    let _ = command.creation_flags(CREATE_NO_WINDOW.0);
    command
}

/// The current user's ID from `id -u`, read once; `None` when it cannot be read.
#[cfg(any(target_os = "linux", target_os = "macos"))]
fn current_uid() -> Option<&'static str> {
    static UID: std::sync::LazyLock<Option<String>> = std::sync::LazyLock::new(|| {
        let output = Command::new("id").arg("-u").stderr(Stdio::null()).output().ok()?;
        let uid = String::from_utf8_lossy(&output.stdout).trim().to_string();
        (output.status.success() && uid.parse::<u32>().is_ok()).then_some(uid)
    });
    UID.as_deref()
}

/// `program` (`pgrep` or `pkill`) matching the exact process name `name`
/// among the current user's processes, or every user's when the ID is unknown,
/// with `extra` arguments before the name.
#[cfg(any(target_os = "linux", target_os = "macos"))]
pub(crate) fn own_process_command(program: &str, extra: &[&str], name: &str) -> Command {
    let mut command = Command::new(program);
    let _ = command.args(extra);
    if let Some(uid) = current_uid() {
        let _ = command.args(["-U", uid]);
    }
    let _ = command.args(["-x", name]);
    command
}

pub(crate) fn process_running(name: &str) -> bool {
    #[cfg(target_os = "linux")]
    {
        own_process_command("pgrep", &[], name).stderr(Stdio::null()).output().is_ok_and(|output| {
            String::from_utf8_lossy(&output.stdout)
                .lines()
                .filter_map(|pid| pid.parse::<u32>().ok())
                .any(linux_process_alive)
        })
    }
    #[cfg(target_os = "macos")]
    {
        own_process_command("pgrep", &[], name)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
            .is_ok_and(|s| s.success())
    }
    #[cfg(windows)]
    {
        background_command("tasklist")
            .args(["/FI", &format!("ImageName eq {name}"), "/NH"])
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .output()
            .is_ok_and(|o| {
                !o.stdout.is_empty()
                    && !o
                        .stdout
                        .windows(b"No tasks are running".len())
                        .any(|w| w == b"No tasks are running")
            })
    }
}

#[cfg(target_os = "linux")]
fn linux_process_alive(pid: u32) -> bool {
    // pgrep includes unreaped children. They cannot exit again or serve a client.
    let alive = std::fs::read_to_string(format!("/proc/{pid}/stat")).is_ok_and(|stat| {
        stat.rsplit_once(')')
            .and_then(|(_, rest)| rest.split_whitespace().next())
            .is_some_and(|state| state != "Z" && state != "X")
    });
    alive
        && std::fs::read(format!("/proc/{pid}/cmdline")).is_ok_and(|args| !is_version_probe(&args))
}

#[cfg(target_os = "linux")]
fn is_version_probe(args: &[u8]) -> bool {
    args.split(|byte| *byte == 0).skip(1).any(|arg| arg == b"--version")
}

#[cfg(all(test, target_os = "linux"))]
mod linux_tests {
    #[test]
    fn version_probes_do_not_count_as_a_running_client() {
        assert!(super::is_version_probe(b"/opt/spotify/spotify\0--version\0"));
        assert!(!super::is_version_probe(b"/opt/spotify/spotify\0--remote-debugging-port=9229\0"));
        assert!(!super::is_version_probe(b"/opt/spotify/spotify\0spotify:track:version\0"));
    }

    #[test]
    fn an_unreaped_child_is_not_a_running_client() {
        let mut child = std::process::Command::new("sleep").arg("30").spawn().unwrap();
        assert!(super::linux_process_alive(child.id()));
        child.kill().unwrap();
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(2);
        while super::linux_process_alive(child.id()) && std::time::Instant::now() < deadline {
            std::thread::sleep(std::time::Duration::from_millis(10));
        }
        let alive = super::linux_process_alive(child.id());
        let _ = child.wait().unwrap();
        assert!(!alive, "a zombie must not prevent Spotify from being relaunched");
    }
}

/// The IDs of live processes named `name`, where the platform can list them.
pub(crate) fn pids(name: &str) -> Option<Vec<u32>> {
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    {
        let output = own_process_command("pgrep", &[], name).stderr(Stdio::null()).output().ok()?;
        let stdout = String::from_utf8_lossy(&output.stdout);
        let pids = stdout.lines().filter_map(|pid| pid.trim().parse::<u32>().ok());
        #[cfg(target_os = "linux")]
        let pids = pids.filter(|pid| linux_process_alive(*pid));
        Some(pids.collect())
    }
    #[cfg(windows)]
    {
        let _ = name;
        None
    }
}

/// Kills every process named `name` with a signal it cannot ignore.
pub(crate) fn kill_image_hard(name: &str) {
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    {
        match own_process_command("pkill", &["-KILL"], name)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
        {
            Ok(s) if s.success() || s.code() == Some(1) => {}
            Ok(s) => tracing::warn!(%name, %s, "pkill -KILL exited with non-zero status"),
            Err(e) => tracing::warn!(%name, error = %e, "failed to run pkill -KILL"),
        }
    }
    #[cfg(windows)]
    kill_image(name);
}

pub(crate) fn kill_image(name: &str) {
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    {
        match own_process_command("pkill", &[], name)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
        {
            Ok(s) if s.success() => {}
            // Exit 1 is "nothing matched", which is the normal outcome when the
            // process already stopped on its own.
            Ok(s) if s.code() == Some(1) => tracing::debug!(%name, "no process left to kill"),
            Ok(s) => tracing::warn!(%name, %s, "pkill exited with non-zero status"),
            Err(e) => tracing::warn!(%name, error = %e, "failed to run pkill"),
        }
    }
    #[cfg(windows)]
    {
        match background_command("taskkill")
            .args(["/F", "/IM", name])
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()
        {
            Ok(s) if s.success() => {}
            Ok(s) => tracing::warn!(%name, %s, "taskkill exited with non-zero status"),
            Err(e) => tracing::warn!(%name, error = %e, "failed to run taskkill"),
        }
    }
}

pub fn spawn_detached(ctx: &AppContext) -> Result<()> {
    #[cfg(target_os = "macos")]
    {
        spawn_macos(ctx)
    }
    #[cfg(windows)]
    {
        spawn_windows(ctx)
    }
    #[cfg(target_os = "linux")]
    {
        spawn_linux(ctx)
    }
}

#[cfg(target_os = "macos")]
fn spawn_macos(ctx: &AppContext) -> Result<()> {
    // Launch the bundle that was actually resolved, not a hardcoded one:
    // `open -a` on a path that does not exist starts nothing, and the caller
    // then waits out its timeout with no idea why.
    let bundle = macos_bundle(&ctx.spotify_exec);
    let child = Command::new("open")
        .arg("-a")
        .arg(&bundle)
        .arg("--args")
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| {
            anyhow::anyhow!("failed to launch Spotify via open -a {}: {e}", bundle.display())
        })?;
    std::mem::forget(child);
    tracing::info!("Spotify launched via open -a {}", bundle.display());
    Ok(())
}

/// `<bundle>/Contents/MacOS/Spotify` back up to `<bundle>`. Falls back to the
/// executable itself, which `open -a` also accepts, when the path is not
/// shaped like a bundle.
#[cfg(target_os = "macos")]
fn macos_bundle(exec: &std::path::Path) -> std::path::PathBuf {
    exec.parent()
        .and_then(std::path::Path::parent)
        .and_then(std::path::Path::parent)
        .filter(|p| p.extension().is_some_and(|ext| ext == "app"))
        .map_or_else(|| exec.to_path_buf(), std::path::Path::to_path_buf)
}

#[cfg(windows)]
fn spawn_windows(ctx: &AppContext) -> Result<()> {
    use std::path::PathBuf;

    use directories::BaseDirs;
    let local_appdata =
        BaseDirs::new().map_or_else(PathBuf::new, |d| d.data_local_dir().to_path_buf());
    let appx_exe = local_appdata.join("Microsoft").join("WindowsApps").join("Spotify.exe");

    if appx_exe.is_file() {
        let dest_apps = ctx.dest_apps_path();
        let ps_cmd =
            format!("& \"{}\" --app-directory=\"{}\"", appx_exe.display(), dest_apps.display());

        let child = background_command("powershell.exe")
            .args(["-NoProfile", "-NonInteractive", "-Command", &ps_cmd])
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| anyhow::anyhow!("failed to launch AppX Spotify: {e}"))?;
        std::mem::forget(child);
        tracing::info!("Spotify (AppX) launched via powershell.exe");
        Ok(())
    } else {
        spawn_binary(ctx)
    }
}

#[cfg(target_os = "linux")]
fn spawn_linux(ctx: &AppContext) -> Result<()> {
    use std::os::unix::process::CommandExt;

    let exe = &ctx.spotify_exec;
    if !exe.is_file() {
        return Err(anyhow::anyhow!("Spotify executable not found at {}", exe.display()));
    }

    match fork::fork() {
        Ok(fork::Fork::Parent(pid)) => {
            tracing::info!(pid, "Spotify process spawned and detached");
            Ok(())
        }
        Ok(fork::Fork::Child) => {
            if let Err(e) = fork::setsid() {
                tracing::error!(error = %e, "setsid failed in child");
                std::process::exit(1);
            }
            let err = Command::new(exe)
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .exec();
            tracing::error!(%err, "exec of Spotify failed");
            std::process::exit(1);
        }
        Err(e) => Err(anyhow::anyhow!("fork failed: {e}")),
    }
}

#[cfg(windows)]
fn spawn_binary(ctx: &AppContext) -> Result<()> {
    use std::os::windows::process::CommandExt;

    use windows::Win32::System::Threading::{
        CREATE_NEW_PROCESS_GROUP, CREATE_NO_WINDOW, DETACHED_PROCESS,
    };

    let exe = &ctx.spotify_exec;
    if !exe.is_file() {
        return Err(anyhow::anyhow!("Spotify executable not found at {}", exe.display()));
    }

    let child = Command::new(exe)
        .creation_flags((CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP | DETACHED_PROCESS).0)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| anyhow::anyhow!("process spawn failed for {}: {e}", exe.display()))?;
    std::mem::forget(child);
    tracing::info!("Spotify process spawned and detached");
    Ok(())
}

pub fn force_kill_spotify(ctx: &AppContext) {
    let image = ctx.spotify_exec.file_name().and_then(|s| s.to_str()).unwrap_or("Spotify");

    if !process_running(image) {
        return;
    }

    tracing::info!("force-killing Spotify processes");
    kill_image(image);
}

#[cfg(all(test, windows))]
mod windows_tests {
    #[test]
    fn background_helpers_have_no_console_and_preserve_output_and_status() {
        let output = super::background_command("powershell.exe")
            .args([
                "-NoProfile", "-NonInteractive", "-Command",
                r#"Add-Type 'using System; using System.Runtime.InteropServices; public class ConsoleProbe { [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow(); }'; [ConsoleProbe]::GetConsoleWindow().ToInt64(); exit 7"#,
            ])
            .output()
            .expect("run background console probe");
        assert_eq!(output.status.code(), Some(7), "child exit status is preserved: {output:?}");
        assert_eq!(String::from_utf8_lossy(&output.stdout).trim(), "0", "no console is allocated");
    }
}

#[cfg(all(test, target_os = "macos"))]
mod tests {
    use super::macos_bundle;
    use std::path::{Path, PathBuf};

    #[test]
    fn bundle_is_derived_from_the_resolved_executable() {
        // The launch path must follow detection: a hardcoded /Applications
        // "launches" nothing on a ~/Applications install and the caller then
        // waits out its start timeout.
        assert_eq!(
            macos_bundle(Path::new("/Users/me/Applications/Spotify.app/Contents/MacOS/Spotify")),
            PathBuf::from("/Users/me/Applications/Spotify.app")
        );
        assert_eq!(
            macos_bundle(Path::new("/Applications/Spotify.app/Contents/MacOS/Spotify")),
            PathBuf::from("/Applications/Spotify.app")
        );
    }

    #[test]
    fn a_non_bundle_executable_is_used_as_is() {
        let exec = Path::new("/opt/spotify/spotify");
        assert_eq!(macos_bundle(exec), exec.to_path_buf(), "open -a accepts the binary too");
    }
}
