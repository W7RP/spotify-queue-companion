#!/usr/bin/env bash
# Full classmap pipeline: migrate → static verify → overlay → CDP e2e DOM verify →
# platform contract (the Spotify runtime paths the wrapper reads).
#
# Usage:
#   ./scripts/classmap-e2e.sh
#   ./scripts/classmap-e2e.sh --skip-migrate --deep
#   ./scripts/classmap-e2e.sh --skip-migrate --skip-static --skip-flatten --skip-cdp   # contract only
#   SPOTIFY_SPA=/path/to/xpui.spa ./scripts/classmap-e2e.sh
#
# Env:
#   SPOTIFY_SPA       Path to xpui.spa (default: macOS Spotify.app)
#   SPOTIFY_VERSION   Exact Spotify version recorded in the static report
#   BASE_CLASSMAP     Base classmap JSON (default: the newest key in ../classmaps)
#   BASE_SPA          Stock xpui.spa of the base build (or BASE_CSS_DIR); required to migrate
#   BASE_CSS_DIR      Directory of the base build's stock CSS
#   OUT_DIR           Output dir (default: $TMPDIR/spicetify-classmap-e2e)
#   CDP_PORT          Remote debugging port (default: 9222)
#   MIN_HIT_RATE      CDP pass threshold (default: 0.25)
#   SPICETIFY         Spicetify binary (default: ~/.spicetify/spicetify)
#
# Notes:
#   - When CDP is not reachable, the script temporarily appends
#     --remote-debugging-port=$CDP_PORT to spotify_launch_flags and restores
#     the original config-xpui.ini on exit.
#   - The platform contract needs an applied client. The run fails when a
#     required path in scripts/platform-contract.json is missing; use
#     --skip-contract for a stock client.
#   - Applied xpui.spa files (spicetify hooks detected) are never used as a
#     migrate target; only stock spa copies are.

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

SKIP_MIGRATE=0
SKIP_STATIC=0
SKIP_CDP=0
SKIP_FLATTEN=0
SKIP_CONTRACT=0
DEEP=0
RESTART=0
ENSURE_CDP=1
MIN_HIT_RATE="${MIN_HIT_RATE:-0.25}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-migrate) SKIP_MIGRATE=1 ;;
    --skip-static) SKIP_STATIC=1 ;;
    --skip-cdp) SKIP_CDP=1 ;;
    --skip-flatten) SKIP_FLATTEN=1 ;;
    --skip-contract) SKIP_CONTRACT=1 ;;
    --deep) DEEP=1 ;;
    --restart) RESTART=1 ;;
    --no-ensure-cdp) ENSURE_CDP=0 ;;
    --min-hit-rate)
      shift
      MIN_HIT_RATE="${1:-}"
      if [[ -z "$MIN_HIT_RATE" ]]; then
        echo "--min-hit-rate requires a value" >&2
        exit 1
      fi
      ;;
    -h|--help)
      sed -n '2,30p' "$0"
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      exit 1
      ;;
  esac
  shift
done

SPOTIFY_SPA="${SPOTIFY_SPA:-}"
SPOTIFY_CSS_DIR="${SPOTIFY_CSS_DIR:-/Applications/Spotify.app/Contents/Resources/Apps/xpui}"
STOCK_SPA_CANDIDATES=(
  "${SPOTIFY_SPA:-}"
  "$HOME/.local/state/spicetify/Backup/xpui.spa"
  "$HOME/Library/Application Support/spicetify/Backup/xpui.spa"
  "/Applications/Spotify.app/Contents/Resources/Apps/xpui.spa"
  "/Applications/Spotify.app/Contents/Resources/Apps/xpui.spa.bak"
)
NEWEST_KEY="$(ls -d "$ROOT"/../classmaps/[0-9][0-9][0-9][0-9][0-9][0-9][0-9] 2>/dev/null | sort | tail -1)"
BASE_CLASSMAP="${BASE_CLASSMAP:-$NEWEST_KEY/classmap.json}"
BASE_SPA="${BASE_SPA:-}"
BASE_CSS_DIR="${BASE_CSS_DIR:-}"
OUT_DIR="${OUT_DIR:-${TMPDIR:-/tmp}/spicetify-classmap-e2e}"
CSS_MAP="${CSS_MAP:-$ROOT/css-map.json}"
CDP_PORT="${CDP_PORT:-9222}"
SPICETIFY="${SPICETIFY:-$HOME/.spicetify/spicetify}"
SPOTIFY_VERSION="${SPOTIFY_VERSION:-}"
NODE="${NODE:-node}"

CLASSMAP_OUT="$OUT_DIR/classmap.json"
REPORT_OUT="$OUT_DIR/report.json"
VERIFY_OUT="$OUT_DIR/verify.json"
CDP_OUT="$OUT_DIR/cdp-e2e-report.json"
CONTRACT_OUT="$OUT_DIR/platform-contract.json"
OVERLAY_OUT="$OUT_DIR/css-map.json"

mkdir -p "$OUT_DIR"

log() { printf '\n\033[1m==> %s\033[0m\n' "$*"; }

# spa_is_applied returns 0 when the given xpui.spa has spicetify hooks
# injected (i.e. it is NOT a stock spa and must not be used as a migrate
# target; hashes in it have already been rewritten to semantic names).
spa_is_applied() {
  local spa="$1"
  unzip -p "$spa" "index.html" 2>/dev/null | grep -qi "spicetify"
}

find_stock_spa() {
  local p
  local have_unzip=1
  command -v unzip >/dev/null 2>&1 || have_unzip=0
  for p in "${STOCK_SPA_CANDIDATES[@]}"; do
    [[ -n "$p" && -f "$p" ]] || continue
    if [[ "$have_unzip" -eq 0 ]]; then
      # Without unzip we cannot detect an applied spa, so only trust
      # Spicetify Backup copies, which are stock by construction.
      case "$p" in
        */spicetify/Backup/*) ;;
        *)
          echo "Skipping unverifiable spa (unzip not installed): $p" >&2
          continue
          ;;
      esac
    elif spa_is_applied "$p"; then
      echo "Skipping applied (non-stock) spa: $p" >&2
      continue
    fi
    echo "$p"
    return 0
  done
  return 1
}

# Prefer stock (pre-rewrite) spa for migrate/static hashing.
# Applied Apps/xpui CSS has already been rewritten by css-map and is a bad
# migrate target (hashes become semantic names).
resolve_target_css_args() {
  local prefer_stock="${1:-0}"
  TARGET_ARGS=()
  local spa=""
  if spa="$(find_stock_spa)"; then
    TARGET_ARGS+=(--target-spa "$spa")
    echo "Using target spa: $spa"
    return 0
  fi
  if [[ "$prefer_stock" == "1" ]]; then
    echo "No stock xpui.spa found for migrate (need Spicetify Backup or unapplied spa)." >&2
    echo "Run: spicetify backup   # creates ~/.local/state/spicetify/Backup/xpui.spa" >&2
    return 1
  fi
  if [[ -d "$SPOTIFY_CSS_DIR" ]]; then
    TARGET_ARGS+=(--target-css-dir "$SPOTIFY_CSS_DIR")
    echo "Using applied css dir (hashes may already be rewritten): $SPOTIFY_CSS_DIR"
    return 0
  fi
  echo "Missing Spotify CSS sources" >&2
  return 1
}

# Original config preservation: when we have to touch config-xpui.ini to
# enable CDP, we back it up first and restore it on exit (any status), so
# the user's spotify_launch_flags are never permanently rewritten.
CFG_PATH=""
CFG_BACKUP=""
restore_config() {
  if [[ -n "$CFG_BACKUP" && -n "$CFG_PATH" && -f "$CFG_BACKUP" ]]; then
    cp "$CFG_BACKUP" "$CFG_PATH"
    rm -f "$CFG_BACKUP"
    echo "Restored original spotify_launch_flags in $CFG_PATH"
  fi
}
trap restore_config EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

ensure_cdp() {
  if curl -sf "http://127.0.0.1:${CDP_PORT}/json/version" >/dev/null; then
    echo "CDP already up on :${CDP_PORT}"
    return 0
  fi

  if [[ ! -x "$SPICETIFY" ]]; then
    echo "CDP down and spicetify not found at $SPICETIFY" >&2
    echo "Start Spotify with --remote-debugging-port=${CDP_PORT} first." >&2
    return 1
  fi

  local cfg="${XDG_CONFIG_HOME:-$HOME/.config}/spicetify/config-xpui.ini"
  if [[ -f "$cfg" ]]; then
    if ! grep -q "remote-debugging-port=${CDP_PORT}" "$cfg" 2>/dev/null; then
      log "Temporarily adding remote-debugging flag to $cfg (restored on exit)"
      CFG_PATH="$cfg"
      CFG_BACKUP="$(mktemp -t spicetify-config-xpui)"
      cp "$cfg" "$CFG_BACKUP"
      "$NODE" - "$cfg" "$CDP_PORT" <<'JS'
const fs = require("node:fs");

const [cfg, port] = process.argv.slice(2);
const debugFlag = `--remote-debugging-port=${port}`;

// Preserve existing flags; only append the debug port. No
// --remote-allow-origins=*: the verifier connects without an Origin
// header, so a wildcard that exposes the logged-in client to any
// local web page is unnecessary.
function merge(value) {
  const parts = value.split("|").filter((p) => p.trim());
  if (!parts.some((p) => p.includes("remote-debugging-port"))) parts.push(debugFlag);
  return parts.join("|");
}

let found = false;
let lines = fs.readFileSync(cfg, "utf8").split(/\r?\n/);
if (lines.at(-1) === "") lines.pop();
lines = lines.map((line) => {
  const stripped = line.trim();
  if (!stripped.startsWith("spotify_launch_flags")) return line;
  found = true;
  const value = stripped.slice(stripped.indexOf("=") + 1).trim();
  return `spotify_launch_flags   = ${merge(stripped.includes("=") ? value : "")}`;
});
if (!found) {
  const section = lines.findIndex((line) => line.trim() === "[Setting]");
  const entry = `spotify_launch_flags   = ${debugFlag}`;
  if (section >= 0) lines.splice(section + 1, 0, entry);
  else lines.push(entry);
}
fs.writeFileSync(cfg, `${lines.join("\n")}\n`);
console.log("updated", cfg);
JS
    fi
  fi

  log "Restarting Spotify via spicetify for CDP"
  "$SPICETIFY" restart
  for i in $(seq 1 30); do
    if curl -sf "http://127.0.0.1:${CDP_PORT}/json/version" >/dev/null; then
      echo "CDP ready after ${i}s"
      return 0
    fi
    sleep 1
  done
  echo "CDP still not reachable on :${CDP_PORT}" >&2
  return 1
}

if [[ "$SKIP_MIGRATE" -eq 0 ]]; then
  log "1/5 migrate classmap"
  if [[ ! -f "$BASE_CLASSMAP" ]]; then
    echo "Missing base classmap: $BASE_CLASSMAP" >&2
    exit 1
  fi
  if [[ -n "$BASE_SPA" && -f "$BASE_SPA" ]]; then
    BASE_ARGS=(--base-spa "$BASE_SPA")
  elif [[ -n "$BASE_CSS_DIR" && -d "$BASE_CSS_DIR" ]]; then
    BASE_ARGS=(--base-css-dir "$BASE_CSS_DIR")
  else
    echo "Set BASE_SPA to the stock xpui.spa of the base build, or BASE_CSS_DIR to its CSS" >&2
    exit 1
  fi
  resolve_target_css_args 1
  "$NODE" scripts/classmap-capture.ts migrate \
    --base-classmap "$BASE_CLASSMAP" \
    "${BASE_ARGS[@]}" \
    "${TARGET_ARGS[@]}" \
    --css-map "$CSS_MAP" \
    --out "$CLASSMAP_OUT" \
    --report "$REPORT_OUT" \
    --threshold 0.55 \
    --allow-partial
else
  log "1/5 migrate skipped"
fi

if [[ "$SKIP_STATIC" -eq 0 ]]; then
  log "2/5 static verify"
  resolve_target_css_args 1 || resolve_target_css_args 0
  VERSION_ARGS=()
  [[ -n "$SPOTIFY_VERSION" ]] && VERSION_ARGS=(--target-version "$SPOTIFY_VERSION")
  "$NODE" scripts/classmap-capture.ts verify \
    --classmap "$CLASSMAP_OUT" \
    --report "$REPORT_OUT" \
    --css-map "$CSS_MAP" \
    "${TARGET_ARGS[@]}" \
    "${VERSION_ARGS[@]+${VERSION_ARGS[@]}}" \
    --out "$VERIFY_OUT"
  "$NODE" scripts/classmap-capture.ts devtools \
    --report "$REPORT_OUT" > "$OUT_DIR/devtools-snippet.js" || true
else
  log "2/5 static verify skipped"
fi

if [[ "$SKIP_FLATTEN" -eq 0 ]]; then
  log "3/5 flatten css-map overlay"
  for f in "$CLASSMAP_OUT" "$REPORT_OUT"; do
    if [[ ! -f "$f" ]]; then
      echo "Missing $f (run migrate first, or point OUT_DIR at existing artifacts)" >&2
      exit 1
    fi
  done
  META_ARGS=()
  [[ -f "$OUT_DIR/META.json" ]] && META_ARGS=(--meta "$OUT_DIR/META.json")
  "$NODE" scripts/classmap-capture.ts flatten \
    --classmap "$CLASSMAP_OUT" \
    --base-classmap "$BASE_CLASSMAP" \
    --css-map "$CSS_MAP" \
    --report "$REPORT_OUT" \
    "${META_ARGS[@]+${META_ARGS[@]}}" \
    --out "$OVERLAY_OUT" \
    --allow-partial
else
  log "3/5 flatten skipped"
fi

if [[ "$SKIP_CDP" -eq 0 ]]; then
  log "4/5 CDP e2e verify"
  if [[ "$ENSURE_CDP" -eq 1 ]]; then
    ensure_cdp
  fi
  NAV_FLAGS=(--navigate)
  if [[ "$DEEP" -eq 1 ]]; then
    NAV_FLAGS=(--deep)
  fi
  RESTART_FLAG=()
  if [[ "$RESTART" -eq 1 ]]; then
    RESTART_FLAG=(--restart)
  fi
  OVERLAY_ARGS=()
  [[ -f "$OVERLAY_OUT" ]] && OVERLAY_ARGS=(--overlay "$OVERLAY_OUT")
  "$NODE" scripts/classmap-cdp-verify.mjs \
    --port "$CDP_PORT" \
    --mode both \
    --classmap "$CLASSMAP_OUT" \
    --css-map "$CSS_MAP" \
    "${OVERLAY_ARGS[@]+${OVERLAY_ARGS[@]}}" \
    --out "$CDP_OUT" \
    --min-hit-rate "$MIN_HIT_RATE" \
    "${NAV_FLAGS[@]}" \
    "${RESTART_FLAG[@]}"
else
  log "4/5 CDP e2e skipped"
fi

if [[ "$SKIP_CONTRACT" -eq 0 ]]; then
  log "5/5 platform contract"
  if [[ "$ENSURE_CDP" -eq 1 ]]; then
    ensure_cdp
  fi
  "$NODE" scripts/platform-contract.ts \
    --port "$CDP_PORT" \
    --out "$CONTRACT_OUT"
else
  log "5/5 platform contract skipped"
fi

log "Done"
echo "Artifacts in $OUT_DIR:"
ls -la "$OUT_DIR" | sed -n '1,30p'
