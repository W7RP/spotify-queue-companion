#!/usr/bin/env node
/**
 * E2E classmap verification against a live Spotify desktop client via CDP.
 *
 * Requires Node.js >= 22 (uses the global WebSocket client).
 *
 * Prerequisites
 * -------------
 * 1. Spicetify applied (for classic/semantic mode) or stock client (hash mode)
 * 2. Remote debugging enabled:
 *      spotify_launch_flags = --remote-debugging-port=9222
 *    (edit config-xpui.ini; `spicetify config` cannot set this field.
 *    --remote-allow-origins is NOT needed: this script connects without an
 *    Origin header, which Chrome allows by default.)
 * 3. Start Spotify via: spicetify restart
 *
 * Usage
 * -----
 *   node scripts/classmap-cdp-verify.mjs --out-dir classmaps/1020092
 *   node scripts/classmap-cdp-verify.mjs --port 9222 --mode both --out-dir classmaps/1020092
 *   node scripts/classmap-cdp-verify.mjs --report <report.json> --classmap <classmap.json> --out <cdp-report.json>
 *   CLASSMAP_OUT_DIR=classmaps/1020092 node scripts/classmap-cdp-verify.mjs --navigate --min-hit-rate 0.3
 *
 * Paths
 * -----
 *   --classmap/--out may be given explicitly, or derived from --out-dir /
 *   CLASSMAP_OUT_DIR. --report is optional; when omitted, every classmap leaf
 *   is probed directly.
 *   --overlay applies a key's css-map.json on top of --css-map, as apply does,
 *   so semantic probes use the names the published key gives its classes.
 *   The report records the digest of both maps.
 *
 * Exit codes
 * ----------
 *   0  hit rate >= --min-hit-rate
 *   1  CDP/runtime failure
 *   2  hit rate below threshold
 */

import { spawnSync } from "node:child_process";
import crypto from "node:crypto";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CLI_ROOT = path.resolve(__dirname, "..");

function parseArgs(argv) {
  const args = {
    port: 9222,
    host: "127.0.0.1",
    mode: "both", // hash | semantic | both
    outDir: process.env.CLASSMAP_OUT_DIR || null,
    report: null,
    classmap: null,
    cssMap: path.join(CLI_ROOT, "css-map.json"),
    overlay: null,
    out: null,
    navigate: false,
    deep: false,
    restart: false,
    minHitRate: 0.25,
    timeoutMs: 15000,
  };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    const next = argv[i + 1];
    const take = () => {
      i++;
      return next;
    };
    switch (a) {
      case "--port":
        args.port = Number(take());
        break;
      case "--host":
        args.host = take();
        break;
      case "--mode":
        args.mode = take();
        break;
      case "--report":
        args.report = path.resolve(take());
        break;
      case "--classmap":
        args.classmap = path.resolve(take());
        break;
      case "--css-map":
        args.cssMap = path.resolve(take());
        break;
      case "--overlay":
        args.overlay = path.resolve(take());
        break;
      case "--out":
        args.out = path.resolve(take());
        break;
      case "--out-dir":
        args.outDir = path.resolve(take());
        break;
      case "--navigate":
        args.navigate = true;
        break;
      case "--deep":
        args.navigate = true;
        args.deep = true;
        break;
      case "--restart":
        args.restart = true;
        break;
      case "--min-hit-rate":
        args.minHitRate = Number(take());
        break;
      case "--timeout-ms":
        args.timeoutMs = Number(take());
        break;
      case "-h":
      case "--help":
        args.help = true;
        break;
      default:
        if (a.startsWith("-")) throw new Error(`Unknown flag: ${a}`);
    }
  }
  if (args.help) return args;
  if (!["hash", "semantic", "both"].includes(args.mode)) {
    throw new Error(`invalid mode: ${args.mode}`);
  }
  if (!Number.isFinite(args.minHitRate) || args.minHitRate < 0 || args.minHitRate > 1) {
    throw new Error(`invalid min hit rate: ${args.minHitRate}`);
  }
  if (!Number.isFinite(args.timeoutMs) || args.timeoutMs <= 0) {
    throw new Error(`invalid timeout: ${args.timeoutMs}`);
  }
  if (!Number.isInteger(args.port) || args.port < 1 || args.port > 65535) {
    throw new Error(`invalid port: ${args.port}`);
  }
  // Derive report/classmap/out from --out-dir when not given explicitly.
  if (!args.classmap || !args.out) {
    if (!args.outDir) {
      throw new Error(
        "Pass --classmap and --out explicitly, or set --out-dir (or CLASSMAP_OUT_DIR) " +
          "to derive them as <out-dir>/{classmap,cdp-e2e-report}.json",
      );
    }
    args.classmap ??= path.join(args.outDir, "classmap.json");
    args.out ??= path.join(args.outDir, "cdp-e2e-report.json");
  }
  return args;
}

function httpGetJson(url, timeoutMs = 3000) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, { timeout: timeoutMs }, (res) => {
      let d = "";
      res.on("data", (c) => (d += c));
      res.on("end", () => {
        try {
          resolve(JSON.parse(d));
        } catch (e) {
          reject(new Error(`Invalid JSON from ${url}: ${e.message}`));
        }
      });
    });
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error(`Timeout fetching ${url}`));
    });
  });
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function waitForCdp(host, port, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastErr;
  while (Date.now() < deadline) {
    try {
      // The version and target list belong to the same readiness attempt.
      // eslint-disable-next-line no-await-in-loop
      const version = await httpGetJson(`http://${host}:${port}/json/version`);
      // eslint-disable-next-line no-await-in-loop
      const targets = await httpGetJson(`http://${host}:${port}/json`);
      return { version, targets };
    } catch (e) {
      lastErr = e;
      // Polling is deliberately sequential to preserve the timeout budget.
      // eslint-disable-next-line no-await-in-loop
      await sleep(500);
    }
  }
  throw new Error(
    `CDP not reachable at http://${host}:${port} within ${timeoutMs}ms` +
      (lastErr ? ` (${lastErr.message})` : "") +
      `\nStart Spotify with remote debugging:\n` +
      `  1. Set in ~/.config/spicetify/config-xpui.ini:\n` +
      `       spotify_launch_flags = --remote-debugging-port=${port}\n` +
      `  2. spicetify restart\n`,
  );
}

export function pickXpuiTarget(targets) {
  const pages = targets.filter((t) => t.type === "page");
  return pages.find((t) => (t.url || "").includes("xpui.app.spotify.com")) || pages.find((t) => (t.url || "").includes("index.html")) || pages[0];
}

/** The CLI css-map with a key's overlay applied on top, as `apply` merges them. */
export function effectiveCssMap(cssMapPath, overlayPath) {
  const base = fs.existsSync(cssMapPath) ? JSON.parse(fs.readFileSync(cssMapPath, "utf8")) : {};
  const overlay = overlayPath ? JSON.parse(fs.readFileSync(overlayPath, "utf8")) : {};
  return { ...base, ...overlay };
}

export function loadChecks({ reportPath, classmapPath, cssMapPath, overlayPath = null }) {
  const cssMap = effectiveCssMap(cssMapPath, overlayPath);

  /** @type {{path:string, hash:string, semantic:string|null, confidence:string}[]} */
  let checks = [];

  if (reportPath && fs.existsSync(reportPath)) {
    const report = JSON.parse(fs.readFileSync(reportPath, "utf8"));
    for (const m of [...(report.matched || []), ...(report.identity || [])]) {
      const hash = m.new || m.class;
      checks.push({
        path: m.path,
        hash,
        semantic: semanticClassName(hash, cssMap),
        confidence: m.confidence || "",
      });
    }
  } else if (fs.existsSync(classmapPath)) {
    const classmap = JSON.parse(fs.readFileSync(classmapPath, "utf8"));
    const walk = (node, parts = []) => {
      if (node && typeof node === "object" && !Array.isArray(node)) {
        for (const [k, v] of Object.entries(node)) walk(v, [...parts, k]);
      } else if (typeof node === "string") {
        checks.push({
          path: parts.join("."),
          hash: node,
          semantic: semanticClassName(node, cssMap),
          confidence: "",
        });
      }
    };
    walk(classmap);
  } else {
    throw new Error(`No report (${reportPath}) or classmap (${classmapPath}) found`);
  }

  // de-dupe by path
  const byPath = new Map();
  for (const c of checks) byPath.set(c.path, c);
  return [...byPath.values()];
}

function semanticClassName(className, cssMap) {
  return className
    .split(/\s+/)
    .map((token) => cssMap[token] || token)
    .join(" ");
}

export class CdpSession {
  constructor(wsUrl) {
    this.wsUrl = wsUrl;
    this.ws = null;
    this.id = 0;
    this.pending = new Map();
  }

  async connect() {
    this.ws = new WebSocket(this.wsUrl);
    await new Promise((resolve, reject) => {
      this.ws.addEventListener("open", resolve);
      this.ws.addEventListener("error", reject);
    });
    this.ws.addEventListener("message", (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) reject(Object.assign(new Error(msg.error.message), msg.error));
        else resolve(msg.result);
      }
    });
    await this.call("Runtime.enable");
    await this.call("Page.enable").catch(() => {});
  }

  call(method, params = {}) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }

  async evaluate(expression) {
    const result = await this.call("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (result.exceptionDetails) {
      const text = result.exceptionDetails.exception?.description || result.exceptionDetails.text || "evaluate failed";
      throw new Error(text);
    }
    return result.result?.value;
  }

  close() {
    try {
      this.ws?.close();
    } catch {
      /* ignore */
    }
  }
}

/** Shared helpers injected into page for navigation recipes. */
/**
 * The menu labels the navigation steps click, in the client's language.
 * `translations` is the client's own i18n/<lang>.json; missing keys fall back
 * to English.
 */
export function menuLabels(translations = {}) {
  const t = (key, english) => (typeof translations[key] === "string" && translations[key]) || english;
  return {
    credits: t("contextmenu.show-credits", "View credits"),
    share: t("contextmenu.share", "Share"),
    embed: [t("ewg.title.track", "Embed track"), t("ewg.title.episode", "Embed episode")],
    settings: t("user.settings", "Settings"),
  };
}

const NAV_HELPERS = `
  const menuLabels = ${menuLabels.toString()};
  const labels = async () => {
    const lang = document.documentElement.lang || "en";
    try {
      const response = await fetch("/i18n/" + lang + ".json");
      if (response.ok) return menuLabels(await response.json());
    } catch {}
    return menuLabels();
  };
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const visible = (el) => {
    if (!el) return false;
    const s = getComputedStyle(el);
    if (s.display === "none" || s.visibility === "hidden" || s.opacity === "0") return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };
  const click = (el) => {
    if (!el) return false;
    el.dispatchEvent(new MouseEvent("pointerdown", { bubbles: true, cancelable: true, view: window }));
    el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    if (typeof el.click === "function") el.click();
    else el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
    el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
    return true;
  };
  const findClickable = (preds) => {
    const nodes = $$("a,button,[role='link'],[role='button'],[data-testid]");
    for (const pred of preds) {
      const hit = nodes.find((el) => visible(el) && pred(el));
      if (hit) return hit;
    }
    return null;
  };
  const textOf = (el) => ((el.getAttribute("aria-label") || "") + " " + (el.textContent || "")).trim();
  const navigateSpa = (pathname) => {
    try {
      // Spicetify / Spotify platform history if present
      const hist =
        window.Spicetify?.Platform?.History ||
        window.Spicetify?.Platform?.PlayerAPI?._history ||
        null;
      if (hist?.push) {
        hist.push(pathname);
        return "platform-history:" + pathname;
      }
    } catch {}
    try {
      history.pushState({}, "", pathname);
      window.dispatchEvent(new PopStateEvent("popstate"));
      return "pushState:" + pathname;
    } catch {
      return "nav-failed:" + pathname;
    }
  };
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const waitFor = async (probe, ms = 3000) => {
    const deadline = Date.now() + ms;
    while (Date.now() < deadline) {
      const value = probe();
      if (value) return value;
      await wait(100);
    }
    return null;
  };
  const openMenu = () => $$('[role="menu"]').find(visible);
  const menuItem = (...texts) =>
    $$('[role="menu"] [role="menuitem"], [role="menu"] button, [role="menu"] a').find((el) => visible(el) && texts.includes((el.textContent || "").trim()));
  const openDialogs = () => $$('dialog[open], [role="dialog"]').filter(visible);
  // Closes open dialogs and menus so the next step starts from the page itself.
  const closeOverlays = async () => {
    for (const dialog of openDialogs()) {
      const close = [...dialog.querySelectorAll("button[aria-label]")].find((b) => /^close$/i.test(b.getAttribute("aria-label")));
      if (close) click(close);
      else dialog.close?.();
    }
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
    await waitFor(() => !openDialogs().length && !openMenu(), 5000);
  };
  // Opens the context menu of the first visible track row.
  const openTrackMenu = async () => {
    // Track rows first: the Your Library sidebar also uses role="row".
    const row = ['main [data-testid="tracklist-row"]', '[data-testid="tracklist-row"]', 'main [data-testid="internal-tracklist-row"]']
      .map((selector) => $$(selector).find(visible))
      .find(Boolean);
    if (!row) return null;
    const rect = row.getBoundingClientRect();
    const opts = { bubbles: true, cancelable: true, view: window, clientX: rect.left + Math.min(40, rect.width / 2), clientY: rect.top + rect.height / 2, button: 2, buttons: 2 };
    row.dispatchEvent(new MouseEvent("contextmenu", opts));
    return waitFor(openMenu, 8000);
  };
`;

const NAV_STEPS = [
  {
    name: "home",
    waitMs: 1000,
    expr: `(() => {
      ${NAV_HELPERS}
      const el = findClickable([
        (e) => e.getAttribute("data-testid") === "home-button" || e.getAttribute("data-testid") === "global-nav-home",
        (e) => /\\bhome\\b/i.test(textOf(e)) && e.tagName === "A",
        (e) => (e.getAttribute("href") || "") === "/" || (e.getAttribute("href") || "").endsWith("/home"),
      ]);
      if (click(el)) return "clicked-home";
      return navigateSpa("/");
    })()`,
  },
  {
    name: "search",
    waitMs: 1200,
    expr: `(() => {
      ${NAV_HELPERS}
      const el = findClickable([
        (e) => (e.getAttribute("data-testid") || "").includes("search"),
        (e) => /\\bsearch\\b/i.test(textOf(e)),
        (e) => (e.getAttribute("href") || "").includes("/search"),
      ]);
      if (click(el)) return "clicked-search";
      const input = $$("input").find((i) => visible(i) && (/search/i.test(i.getAttribute("data-testid") || "") || i.getAttribute("role") === "searchbox" || /search/i.test(i.placeholder || "")));
      if (input) {
        input.focus();
        input.value = "a";
        input.dispatchEvent(new Event("input", { bubbles: true }));
        return "typed-search";
      }
      return navigateSpa("/search");
    })()`,
  },
  {
    name: "library",
    waitMs: 1200,
    expr: `(() => {
      ${NAV_HELPERS}
      const el = findClickable([
        (e) => (e.getAttribute("data-testid") || "").includes("library") || (e.getAttribute("data-testid") || "") === "your-library-button",
        (e) => /your library|library/i.test(textOf(e)),
        (e) => (e.getAttribute("href") || "").includes("/collection"),
      ]);
      if (click(el)) return "clicked-library";
      return navigateSpa("/collection");
    })()`,
  },
  {
    name: "playlist",
    waitMs: 300,
    expr: `(async () => {
      ${NAV_HELPERS}
      // Only real links: a filter chip such as "Playlists" matches a looser test and navigates nowhere.
      const links = () => $$("a[href]").filter((a) => visible(a) && /^\\/(playlist|album)\\/|^\\/collection\\/tracks/.test(a.getAttribute("href")));
      if (!links().length) {
        click(findClickable([(e) => e.getAttribute("data-testid") === "home-button"]));
        await waitFor(() => links().length, 15000);
      }
      const tracksRendered = () => waitFor(() => $$('main [data-testid="tracklist-row"]').some(visible), 45000);
      for (const link of links().slice(0, 2)) {
        const target = link.getAttribute("href");
        click(link);
        if (await tracksRendered()) return "clicked-playlist-or-liked:" + target;
      }
      return links().length ? "tracks-not-rendered" : "no-playlist-link";
    })()`,
  },
  {
    name: "context_menu",
    waitMs: 300,
    expr: `(async () => {
      ${NAV_HELPERS}
      if (await openTrackMenu()) return "context-menu-open";
      return $$('[data-testid="tracklist-row"], [role="row"]').find(visible) ? "context-menu-dispatched" : "no-track-row";
    })()`,
  },
  {
    name: "track_credits",
    waitMs: 300,
    expr: `(async () => {
      ${NAV_HELPERS}
      if (!openMenu() && !(await openTrackMenu())) return "no-track-row";
      const item = menuItem((await labels()).credits);
      if (!click(item)) return "credits-not-found";
      return (await waitFor(() => openDialogs().length, 10000)) ? "credits-open" : "credits-not-found";
    })()`,
  },
  {
    name: "embed",
    waitMs: 300,
    expr: `(async () => {
      ${NAV_HELPERS}
      await closeOverlays();
      if (!(await openTrackMenu())) return "no-track-row";
      const text = await labels();
      const share = menuItem(text.share);
      if (!share) return "embed-not-found";
      share.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
      click(share);
      const embed = await waitFor(() => menuItem(...text.embed), 8000);
      if (!click(embed)) return "embed-not-found";
      return (await waitFor(() => openDialogs().length, 10000)) ? "embed-open" : "embed-not-found";
    })()`,
  },
  {
    name: "sort_or_filter",
    waitMs: 800,
    expr: `(async () => {
      ${NAV_HELPERS}
      await closeOverlays();
      const el = findClickable([
        (e) => /sort|filter|custom order|recently|title|artist/i.test(textOf(e)),
        (e) => (e.getAttribute("data-testid") || "").includes("sort"),
      ]);
      if (click(el)) return "clicked-sort-filter";
      return "sort-not-found";
    })()`,
  },
  {
    name: "settings",
    waitMs: 300,
    expr: `(async () => {
      ${NAV_HELPERS}
      await closeOverlays();
      // Settings opens from the account menu; a pushed history entry doesn't render it.
      const profile = findClickable([(e) => (e.getAttribute("data-testid") || "") === "user-widget-link"]);
      if (click(profile)) {
        const settingsLabel = (await labels()).settings;
        const item = await waitFor(() => menuItem(settingsLabel), 8000);
        if (click(item)) {
          const rendered = await waitFor(() => $$("main input, main select").length > 5, 20000);
          return rendered ? "settings-open" : "settings-not-rendered";
        }
      }
      return navigateSpa("/preferences");
    })()`,
  },
  {
    name: "settings_scroll",
    waitMs: 300,
    expr: `(async () => {
      ${NAV_HELPERS}
      // Scroll the whole settings page so lazily mounted sections render.
      const inputs = $$("main input, main select");
      let scroller = inputs[0];
      while (scroller && !(scroller.scrollHeight > scroller.clientHeight + 50 && /auto|scroll/.test(getComputedStyle(scroller).overflowY))) {
        scroller = scroller.parentElement;
      }
      if (!scroller) return "no-settings-scroll-target";
      for (let y = 0; y <= scroller.scrollHeight; y += 500) {
        scroller.scrollTop = y;
        await wait(120);
      }
      return "scrolled-settings";
    })()`,
  },
];

export function navigationSucceeded(result) {
  return (
    typeof result === "string" &&
    !/^(?:nav-failed|context-menu-dispatched|no-track-row|sort-not-found|no-settings-scroll-target|credits-not-found|embed-not-found|settings-not-rendered|tracks-not-rendered|no-playlist-link)(?::|$)/.test(
      result,
    )
  );
}

function buildProbeExpression(checks) {
  return `(() => {
    const checks = ${JSON.stringify(checks)};
    const probeOne = (cls) => {
      if (!cls) return { count: 0, sample: null };
      const nodes = document.getElementsByClassName(cls);
      const el = nodes[0];
      if (!el) return { count: 0, sample: null };
      return {
        count: nodes.length,
        sample: {
          tag: el.tagName,
          className: String(el.className).slice(0, 160),
          text: (el.textContent || "").trim().replace(/\\s+/g, " ").slice(0, 80),
          aria: el.getAttribute("aria-label"),
        },
      };
    };
    return {
      meta: {
        ready: document.readyState,
        href: location.href,
        title: document.title,
        mainLike: document.querySelectorAll('[class*="main-"]').length,
      },
      rows: checks.map((c) => {
        const hash = probeOne(c.hash);
        const semantic = probeOne(c.semantic);
        return {
          path: c.path,
          hash: c.hash,
          semantic: c.semantic,
          confidence: c.confidence,
          byHash: hash.count,
          bySem: semantic.count,
          sample: semantic.sample || hash.sample,
        };
      }),
    };
  })()`;
}

function summarize(rows, mode) {
  const scored = rows.map((r) => {
    const hashHit = r.byHash > 0;
    const semHit = r.bySem > 0;
    let hit = false;
    if (mode === "hash") hit = hashHit;
    else if (mode === "semantic") hit = semHit;
    else hit = hashHit || semHit;
    return { ...r, hit, hashHit, semHit };
  });
  const hits = scored.filter((r) => r.hit).length;
  return {
    total: scored.length,
    hits,
    hitRate: scored.length ? hits / scored.length : 0,
    hashHits: scored.filter((r) => r.hashHit).length,
    semanticHits: scored.filter((r) => r.semHit).length,
    rows: scored,
  };
}

function mergeBest(acc, next) {
  // Keep max counts per path across navigation steps
  const byPath = new Map(acc.map((r) => [r.path, r]));
  for (const r of next) {
    const prev = byPath.get(r.path);
    if (!prev) {
      byPath.set(r.path, r);
      continue;
    }
    byPath.set(r.path, {
      ...prev,
      byHash: Math.max(prev.byHash, r.byHash),
      bySem: Math.max(prev.bySem, r.bySem),
      sample: r.bySem || r.byHash ? r.sample || prev.sample : prev.sample,
    });
  }
  return [...byPath.values()];
}

function maybeRestartSpicetify() {
  const bin = process.env.SPICETIFY || `${process.env.HOME}/.spicetify/spicetify`;
  if (!fs.existsSync(bin)) {
    console.warn(`spicetify binary not found at ${bin}; skip --restart`);
    return;
  }
  console.log(`Restarting Spotify via ${bin} …`);
  const r = spawnSync(bin, ["restart"], { encoding: "utf8" });
  if (r.stdout) process.stdout.write(r.stdout);
  if (r.stderr) process.stderr.write(r.stderr);
  if (r.status !== 0) {
    throw new Error(`spicetify restart failed with status ${r.status}`);
  }
}

async function main() {
  if (typeof WebSocket === "undefined") {
    console.error(
      `This script needs Node.js >= 22 (global WebSocket client). Current: ${process.version}. ` + `Upgrade Node or run with a newer runtime.`,
    );
    process.exit(1);
  }

  const args = parseArgs(process.argv);
  if (args.help) {
    console.log(fs.readFileSync(fileURLToPath(import.meta.url), "utf8").slice(0, 1200));
    process.exit(0);
  }

  if (args.restart) maybeRestartSpicetify();

  console.log(`Waiting for CDP at ${args.host}:${args.port} …`);
  const { version, targets } = await waitForCdp(args.host, args.port, args.timeoutMs);
  console.log(`Connected: ${version.Browser || version["User-Agent"] || "ok"}`);

  const page = pickXpuiTarget(targets);
  if (!page?.webSocketDebuggerUrl) {
    throw new Error(`No xpui page target in CDP list (${targets.length} targets)`);
  }
  console.log(`Page: ${page.url}`);

  const checks = loadChecks({
    reportPath: args.report,
    classmapPath: args.classmap,
    cssMapPath: args.cssMap,
    overlayPath: args.overlay,
  });
  console.log(`Loaded ${checks.length} classmap paths`);

  const session = new CdpSession(page.webSocketDebuggerUrl);
  await session.connect();

  const steps = [];
  const navigation = { attempted: 0, succeeded: 0, failed: [] };
  let rows = [];

  const runProbe = async (label) => {
    const result = await session.evaluate(buildProbeExpression(checks));
    steps.push({ label, meta: result.meta, at: new Date().toISOString() });
    rows = rows.length ? mergeBest(rows, result.rows) : result.rows;
    const summary = summarize(result.rows, args.mode);
    console.log(
      `  [${label}] hits=${summary.hits}/${summary.total} (hash=${summary.hashHits}, semantic=${summary.semanticHits}) href=${result.meta?.href || "?"}`,
    );
    return result;
  };

  // A slow client (an emulated VM) can take a minute to render its shell after the page loads.
  const ready = await session.evaluate(`(async () => {
    ${NAV_HELPERS}
    return Boolean(await waitFor(() => $$("button").length > 50 && document.querySelector('[data-testid="home-button"], [data-testid="global-nav-bar"], nav'), ${args.timeoutMs}));
  })()`);
  if (!ready) console.warn(`  app shell not rendered within ${args.timeoutMs}ms; probing anyway`);
  await runProbe("initial");

  if (args.navigate) {
    // --deep runs the full recipe list; plain --navigate keeps shell-level steps only.
    const stepsToRun = args.deep ? NAV_STEPS : NAV_STEPS.filter((s) => ["home", "search", "library", "settings"].includes(s.name));
    for (const step of stepsToRun) {
      navigation.attempted++;
      try {
        // Navigation recipes are stateful and must run in order.
        // eslint-disable-next-line no-await-in-loop
        const navResult = await session.evaluate(step.expr);
        console.log(`  navigate:${step.name} -> ${navResult}`);
        if (!navigationSucceeded(navResult)) {
          navigation.failed.push({ name: step.name, error: String(navResult) });
          continue;
        }
        // eslint-disable-next-line no-await-in-loop
        await sleep(step.waitMs || 1200);
        // eslint-disable-next-line no-await-in-loop
        await runProbe(`after:${step.name}`);
        navigation.succeeded++;
      } catch (e) {
        navigation.failed.push({ name: step.name, error: String(e?.message || e) });
        console.warn(`  navigate:${step.name} failed: ${e.message}`);
      }
    }
  }

  const summary = summarize(rows, args.mode);
  const report = {
    generatedAt: new Date().toISOString(),
    cdp: { host: args.host, port: args.port, page: page.url, browser: version },
    classmap: {
      sha256: crypto.createHash("sha256").update(fs.readFileSync(args.classmap)).digest("hex"),
    },
    cssMap: {
      sha256: fs.existsSync(args.cssMap) ? crypto.createHash("sha256").update(fs.readFileSync(args.cssMap)).digest("hex") : null,
      overlaySha256: args.overlay ? crypto.createHash("sha256").update(fs.readFileSync(args.overlay)).digest("hex") : null,
    },
    mode: args.mode,
    minHitRate: args.minHitRate,
    navigate: args.navigate,
    deep: args.deep,
    navigation,
    steps,
    summary: {
      total: summary.total,
      hits: summary.hits,
      hitRate: Number(summary.hitRate.toFixed(4)),
      hashHits: summary.hashHits,
      semanticHits: summary.semanticHits,
    },
    rows: summary.rows.sort((a, b) => Number(b.hit) - Number(a.hit) || a.path.localeCompare(b.path)),
  };

  fs.mkdirSync(path.dirname(args.out), { recursive: true });
  fs.writeFileSync(args.out, JSON.stringify(report, null, 2) + "\n");
  console.log(`\nWrote ${args.out}`);
  console.log(`Overall hit rate (${args.mode}): ${(summary.hitRate * 100).toFixed(1)}% ` + `(${summary.hits}/${summary.total})`);

  console.log("\nPresent:");
  for (const r of summary.rows.filter((r) => r.hit)) {
    console.log(`  ✓ ${r.path}  hash=${r.byHash} sem=${r.bySem}  ${r.semantic || r.hash}`);
  }
  console.log("\nMissing on probed pages:");
  for (const r of summary.rows.filter((r) => !r.hit)) {
    console.log(`  ✗ ${r.path}  (${r.semantic || r.hash})`);
  }

  session.close();

  if (summary.hitRate + 1e-9 < args.minHitRate) {
    console.error(`\nFAIL: hit rate ${summary.hitRate.toFixed(3)} < min ${args.minHitRate}`);
    process.exit(2);
  }
  console.log("\nPASS");
  process.exit(0);
}

if (import.meta.main) {
  main().catch((err) => {
    console.error(err.message || err);
    process.exit(1);
  });
}
